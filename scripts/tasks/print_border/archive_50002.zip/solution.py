s = input()
print('#' * (len(s) + 4))
print('# {} #'.format(s))
print('#' * (len(s) + 4))