s = int(input())

print(('#' * s + '\n') * s)