N, M = map(int, input().split())
num = [[int(i) for i in input().split()] for j in range(N)]
d = [[0 for i in range(M)] for j in range(N)]
d[0][0] = num[0][0]
ans = []
p = [[0 for i in range(M)] for j in range(N)]
for i in range(0, N):
    for j in range(0, M):
        if i > 0 and j > 0:
            d[i][j] = max(d[i][j - 1], d[i - 1][j]) + num[i][j]
            if d[i][j - 1] > d[i - 1][j]:
                p[i][j] = [i, j - 1, 'R']
            else:
                p[i][j] = [i - 1, j, 'D']
        elif i == 0 and j == 0:
            d[i][j] = num[i][j]
            p[i][j] = 0
        elif i == 0:
            d[i][j] = d[i][j - 1] + num[i][j]
            p[i][j] = [i, j - 1, 'R']
        elif j == 0:
            d[i][j] = d[i - 1][j] + num[i][j]
            p[i][j] = [i - 1, j, 'D']
print(d[N - 1][M - 1])
x = N - 1
y = M - 1
while x > 0 or y > 0:
    ans.append(p[x][y][2])
    x, y = p[x][y][0], p[x][y][1]
print(*ans[::-1])