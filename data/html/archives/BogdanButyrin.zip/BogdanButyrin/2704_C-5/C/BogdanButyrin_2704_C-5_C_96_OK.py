N = int(input())
cost = [0] + [int(i) for i in input().split()]
if len(cost) == 1:
    print(cost[0])
elif len(cost) == 2:
    print(cost[1])
else:
    d = [0] * (N + 1)
    d[1] = cost[1]
    d[2] = cost[2]
    for i in range(3, N + 1):
        d[i] = cost[i] + min(d[i - 1], d[i - 2])
    print(d[N])