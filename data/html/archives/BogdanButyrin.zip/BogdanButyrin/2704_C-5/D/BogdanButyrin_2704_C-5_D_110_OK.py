N = int(input())
d = [10 ** 18] * (N + 1)
d[1] = 1
p = [0] + [1] * (N + 1)
for i in range(1, N + 1):
    if i + 1 < N + 1 and d[i + 1] > d[i] + 1:
        d[i + 1] = d[i] + 1
        p[i + 1] = i
    if i * 2 < N + 1 and d[i * 2] > d[i] + 1:
        d[i * 2] = d[i] + 1
        p[i * 2] = i
    if i * 3 < N + 1 and d[i * 3] > d[i] + 1:
        d[i * 3] = d[i] + 1
        p[i * 3] = i
ans = ''
if N != 1:
    while N != 1:
        if N - 1 == p[N]:
            ans += '1'
        elif N // 2 == p[N] and N % 2 == 0:
            ans += '2'
        elif N // 3 == p[N] and N % 3 == 0:
            ans += '3'
        N = p[N]
print(ans[::-1])