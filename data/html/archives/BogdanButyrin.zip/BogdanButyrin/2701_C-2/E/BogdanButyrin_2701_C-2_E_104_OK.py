N = int(input())
A = sorted(list(map(int, input().split())))
M = int(input())
B = list(map(int, input().split()))
def left(x, A):
    l = 0
    r = len(A)
    while r - l > 1:
        m = (r + l) // 2
        if A[m] <= x:
            l = m
        else:
            r = m
    return l
def right(x, A):
    l = -1
    r = len(A) - 1
    while r - l > 1:
        m = (r + l) // 2
        if A[m] >= x:
            r = m
        else:
            l = m
    return r
for elem in B:
    l = left(elem, A)
    r = right(elem, A)
    if A[l] != elem:
        print(0, end=' ')
    else:
        print(l - r + 1, end=' ')