N, K = map(int, input().split())
A = list(map(int, input().split()))
B = list(map(int, input().split()))
def bin_find(x, A):
    l = 0
    r = N
    while r - l > 1:
        m = (r + l) // 2
        if A[m] <= x:
            l = m
        else:
            r = m
    if A[l] == x:
        return 'YES'
    else:
        return'NO'
for i in range(K):
    print(bin_find(B[i], A))
    
