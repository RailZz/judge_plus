c = float(input())
l = 1.0
r = float(10**10)
for i in range(200):
    m = (r + l) / 2
    my = m**2 + m ** 0.5
    if my > c:
        r = m
    else:
        l = m
print(l)