N = int(input())
k = 0
s = 1
while N > s:
    s *= 2
    k += 1
print(k)