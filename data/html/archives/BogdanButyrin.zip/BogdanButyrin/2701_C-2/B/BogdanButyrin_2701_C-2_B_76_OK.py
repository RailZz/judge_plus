from math import sin, pi
a = float(input())
l = -1 * pi/2
r = pi/2
for i in range(100):
    m = (r + l) / 2
    my = sin(m)
    if my > a:
        r = m
    else:
        l = m
print(l)