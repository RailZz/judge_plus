def dfs(x, y, used):
    global S
    S += 1
    used[x][y] = 1
    for d in range(4):
        nx = x + dx[d]
        ny = y + dy[d]
        if 0 <= nx < N and 0 <= ny < N:
            if used[nx][ny] == 0 and field[nx][ny] == '.':
                dfs(nx, ny, used)


N = int(input())
S = 0
dx = [0, 1, 0, -1]
dy = [-1, 0, 1, 0]
used = [[0 for i in range(N)] for j in range(N)]
field = [[elem for elem in ' '.join(input()).split()] for i in range(N)]
x, y = [int(i) - 1 for i in input().split()]
dfs(x, y, used)
print(S)