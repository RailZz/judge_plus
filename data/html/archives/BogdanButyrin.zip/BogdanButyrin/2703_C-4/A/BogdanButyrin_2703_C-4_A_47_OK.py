N, M = map(int, input().split())
lights = [0] * N
for i in range(M):
    a, b = map(int, input().split())
    a, b = a - 1, b - 1
    lights[a] += 1
    lights[b] += 1
print(*lights)