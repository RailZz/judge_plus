N, M = map(int, input().split())
lights = [[] for i in range(N)]
for i in range(M):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    lights[a].append(1)
    lights[b].append(1)
for lights_v in lights:
    print(sum(lights_v), end=' ')