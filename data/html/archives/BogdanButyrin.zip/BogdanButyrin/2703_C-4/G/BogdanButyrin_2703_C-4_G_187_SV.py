def dfs(v, used, M):
    used[v] = 1
    global cycle
    for i in range(N):
        if used[i] == 0 and M[v][i] == 1:
            dfs(i, used, M)
        elif used[i] == 1 and M[v][i] == 1:
            cycle = 1
    used[v] = 2

cycle = 0
N = int(input())
used = [0] * N
M = [[int(i) for i in input().split()] for j in range(N)]
for i in range(N):
    if used[i] == 0:
        dfs(i, used, M)
print(cycle)