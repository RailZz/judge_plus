def dfs(vert, neighbours, used):
    used[vert] = 1
    for new in neighbours[vert]:
        if used[new] == 0:
            dfs(new, neighbours, used)


def dfs_tree(v, neightbours, p, used):
    used[v] = 1
    for new in neighbours[v]:
        if used[new] == 0:
            if dfs_tree(new, neighbours, v, used):
                return False
        else:
            if used[new] == 1 and new != p:
                return False
    return True


N, M = map(int, input().split())
neighbours = [[] for i in range(N)]
used = [0] * N
for i in range(M):
    a, b = map(lambda x: int(x) - 1, input().split())
    neighbours[a].append(b)
    neighbours[b].append(a)
    
dfs(0, neighbours, used)
if sum(used) == N:
    used = [0] * N
    used[0] = 1
    if dfs_tree(1, neighbours, 0, used):
        print('YES')
    else:
        print('NO')
else:
    print('NO')

