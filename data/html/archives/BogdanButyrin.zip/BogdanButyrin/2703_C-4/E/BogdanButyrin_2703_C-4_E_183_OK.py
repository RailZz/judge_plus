def dfs(v, used, p):
    used[v] = 1
    global cycle
    for i in G[v]:
        if used[i] == 0:
            dfs(i, used, v)
        else:
            if i != p and used[i] == 1:
                cycle = 1


N, M = [int(i) for i in input().split()]
G = [[] for i in range(N)]
used = [0] * N
cycle = 0
for i in range(M):
    a, b = [int(i) - 1 for i in input().split()]
    G[a].append(b)
    G[b].append(a)
dfs(0, used, -1)
if cycle == 0 and sum(used) == N:
    print('YES')
else:
    print('NO')
