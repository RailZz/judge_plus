def dfs(v, used, color):
    used[v] = color
    global errors
    for i in G[v]:
        if used[i] == 0:
            dfs(i, used, 3 - color)
        elif used[i] == color:
            errors = 1
    

N, M = map(int, input().split())
G = [[] for i in range(N)]
for i in range(M):
    a, b = map(lambda x: int(x) - 1, input().split())
    G[a].append(b)
    G[b].append(a)
used = [0] * N
errors = 0
for i in range(N):
    if used[i] == 0:
        dfs(i, used, 1)
if errors == 1:
    print('NO')
else:
    print('YES')
    for vert in used:
        if vert == 1:
            print(vert, end=' ')
