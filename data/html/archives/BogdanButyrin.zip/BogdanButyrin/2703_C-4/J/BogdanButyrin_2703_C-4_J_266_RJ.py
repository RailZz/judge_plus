from collections import deque
N = int(input())
G = [[int(i) for i in input().split()] for j in range(N)]
start, finish = [int(i) - 1 for i in input().split()]
used = [0] * N
p = [1] * N
q = deque()
q.append(start)
way = []
d = [100] * N
while len(q) > 0:
    c = q.popleft()
    for i in range(N):
        if used[i] == 0 and G[c][i] == 1:
            p[i] = c
            used[i] = 1
            d[i] = d[c] + 1
            q.append(i)


if start == finish:
    print(0)
else:
    while finish != start and i < max(d):
        way.append(finish + 1)
        finish = p[finish]
        i += 1
    way.append(start + 1)
    k = len(way)
    if k - 1 == 0 or k > N:
        print(-1)
    else:
        print(k - 1)
        print(*way[::-1])