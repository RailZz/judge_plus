n = int(input())
matrix = [[int(i) for i in input().split()] for j in range(n)]
from_verts = []
to_verts = []
for i in range(n):
    in_edges = 0
    from_edges = sum(matrix[i])
    for j in range(n):
        in_edges += matrix[j][i]
    if from_edges > 0 and in_edges == 0:
        from_verts.append(i + 1)
    elif from_edges == 0 and in_edges > 0:
        to_verts.append(i + 1)
    elif from_edges == 0 and in_edges == 0:
        from_verts.append(i + 1)
        to_verts.append(i + 1)
print(len(from_verts))
for elem in from_verts:
    print(elem)
print(len(to_verts))
for elem in to_verts:
    print(elem)
