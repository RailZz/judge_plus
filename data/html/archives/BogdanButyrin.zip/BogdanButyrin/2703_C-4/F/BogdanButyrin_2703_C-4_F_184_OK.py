from sys import setrecursionlimit
setrecursionlimit(10**9)


def dfs(v, used, cur_v):
    used[v] = 1
    cur_v.append(v)
    for i in G[v]:
        if used[i] == 0:
            dfs(i, used, cur_v)


N, M = [int(i) for i in input().split()]
G = [[] for i in range(N)]
used = [0] * N
cycle = 0
comp = 0
partition = []
for i in range(M):
    a, b = [int(i) - 1 for i in input().split()]
    G[a].append(b)
    G[b].append(a)
for i in range(N):
    if used[i] == 0:
        cur_v = []
        dfs(i, used, cur_v)
        comp += 1
        partition.append(cur_v)
print(comp)
for cur_v in partition:
    print(len(cur_v))
    print(*[i + 1 for i in cur_v])       