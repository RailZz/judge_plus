from sys import setrecursionlimit
setrecursionlimit(10 ** 9)


def dfs(x, y, used):
    used[x][y] = 1
    for d in range(4):
        nx = x + dx[d]
        ny = y + dy[d]
        if 0 <= nx < M and 0 <= ny < N:
            if used[nx][ny] == 0 and paper[nx][ny] == '#':
                dfs(nx, ny, used)


M, N = map(int, input().split())
comp = 0
dx = [0, 1, 0, -1]
dy = [-1, 0, 1, 0]
used = [[0 for i in range(N)] for j in range(M)]
paper = [input() for i in range(M)]
for i in range(M):
    for j in range(N):
        if paper[i][j] == '#' and used[i][j] == 0:
            comp += 1
            dfs(i, j, used)
print(comp)