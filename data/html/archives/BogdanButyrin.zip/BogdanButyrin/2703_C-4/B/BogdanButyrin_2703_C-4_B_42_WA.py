N, S = map(int, input().split())
used = [0] * (N + 1)
matrix= [[int(i) for i in input().split()] for j in range(N)]
def dfs(vert, matrix, used):
    global N
    used[vert] = 1
    for new in range(N):
        if matrix[vert - 1][new] == 1 and used[new] == 0:
            dfs(new, matrix, used)
dfs(S, matrix, used)
print(sum(used))
    