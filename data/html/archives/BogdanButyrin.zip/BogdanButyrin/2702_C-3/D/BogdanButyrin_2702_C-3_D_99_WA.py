N, K = map(int, input().split())
S = list(map(int, input().split()))
l = 0
r = S[-1] - S[0]

def f(L):
  global N
  global K
  global S
  n = 0
  for i in range(S[0], S[-1] + 1, L):
    if i in set(S):
      n += 1
  return n >= K

while r - l > 1:
  m = (r + l)//2
  if f(m):
    l = m
  else:
    r = m
print(l)
