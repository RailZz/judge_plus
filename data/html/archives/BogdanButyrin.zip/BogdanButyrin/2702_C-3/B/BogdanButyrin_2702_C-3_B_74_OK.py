N, K = map(int, input().split())
Len = []
for i in range(N):
  x = int(input())
  Len.append(x)
l = 0
r = 10**10
def f(L):
  global K
  global Len
  s = 0
  for elem in Len:
    s += elem//L
  return s >= K
while r - l > 1:
  m = (r + l) // 2
  if f(m):
    l = m
  else:
    r = m
print(l)
