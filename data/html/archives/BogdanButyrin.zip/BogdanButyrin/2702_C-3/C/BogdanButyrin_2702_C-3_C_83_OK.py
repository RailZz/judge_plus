A, K, B, M, X = map(int, input().split())
l = 0
r = (A + B) * X
def f(D):
  global A
  global K
  global B
  global M
  global X
  k = A * (D - D//K) + B * (D - D//M)
  return k >= X
while r - l > 1:
  m = (r + l)//2
  if f(m):
    r = m
  else:
    l = m
print(r)