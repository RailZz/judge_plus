s = input()
if s == s[::-1]:
    print('yes')
else:
    print('no')