N = int(input())
A = list(map(int, input().split()))
K = int(input())
sums = []
for i in range(K):
    a = list(map(int, input().split()))
    sums.append(sum(A[a[0]-1:a[1]]))
print(*sums)
