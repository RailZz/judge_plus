N = int(input())
A = list(map(int, input().split()))
K = int(input())
sums = [0] * K
for i in range(K):
    x, y = map(int, input().split())
    sums[i] = sum(A[x-1:y])
print(*sums)
