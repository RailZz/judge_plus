N = int(input())
A = list(map(int, input().split()))
K = int(input())
sums = []
for i in range(K):
    a = list(map(int, input().split()))
    x = a[0]
    y = a[1]
    sums.append(sum(A[x-1:y]))
print(*sums)
