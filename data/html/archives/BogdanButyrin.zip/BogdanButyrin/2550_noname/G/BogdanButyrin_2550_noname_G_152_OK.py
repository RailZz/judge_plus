n = int(input())
for m in range(2, int(n ** 0.5) + 1):
    if n % m == 0:
        print('composite')
        break
else:
    print('prime')
    
