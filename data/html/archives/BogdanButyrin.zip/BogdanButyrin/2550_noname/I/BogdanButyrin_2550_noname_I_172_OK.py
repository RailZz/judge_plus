N, K = map(int, input().split())
A = set(map(int, input().split()))
B = list(map(int, input().split()))
for elem in B:
    if elem in A:
        print('YES')
    else:
        print('NO')