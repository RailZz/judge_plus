n = int(input())
print('The next number for the number', str(n), 'is', str(n + 1) + '.')
print('The previous number for the number', str(n), 'is', str(n - 1) +'.')