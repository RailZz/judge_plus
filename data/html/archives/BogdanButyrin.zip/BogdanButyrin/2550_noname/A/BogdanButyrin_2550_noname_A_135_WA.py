n = int(input())
print('The next number for the number', n, 'is', n + 1)
print('The previous number for the number', n, 'is', n - 1)