N = int(input())
s = 0
for i in range(N):
    x = int(input())
    s += x
print(s)