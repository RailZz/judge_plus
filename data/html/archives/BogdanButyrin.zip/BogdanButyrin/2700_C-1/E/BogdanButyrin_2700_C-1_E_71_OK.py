a, b, c, d = map(int, input().split())
def gcd(a, b):
  while a != 0 and b != 0:
    a, b = b, a % b
  return a + b
def lcd(a, b):
  return (a * b) // gcd(a, b)
x = lcd(b, d)
new_up = a * x // b + c * x // d
print(new_up//gcd(new_up, x), x//gcd(new_up, x))
