def gcd(a, b):
  while a != 0 and b != 0:
    a, b = b, a % b
  return a + b

N = int(input())
ns = list(map(int, input().split()))
s = ns[0]
for elem in ns:
  s = gcd(s, elem)
print(s)