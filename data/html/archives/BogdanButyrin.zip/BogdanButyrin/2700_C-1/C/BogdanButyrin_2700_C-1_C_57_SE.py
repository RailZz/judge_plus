from math import gcd
N = int(input())
ns = list(map(int, input().split()))
s = ns[0]
for elem in ns:
  s = gcd(s, elem)
print(s)