N = int(input())
sv = [0] * (N + 1)
for i in range(2, N + 1):
  if sv[i] == 0:
    for j in range(i*2, N + 1, i):
      sv[j] = 1
ans = []
for x in range(2, N + 1):
  if sv[x] != 1:
    ans.append(x)

i = 0
while i < len(ans):
  j = i
  while j < len(ans):
    if ans[i] + ans[j] == N:
       x, y = ans[i], ans[j]
       j = i = len(ans)
    j += 1
  i += 1
print(x, y)