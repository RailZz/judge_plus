N = int(input())
sv = [0] * (N + 1)
for i in range(2, N + 1):
  if sv[i] == 0:
    for j in range(i*2, N + 1, i):
      sv[j] = 1
ans = []
for x in range(2, N + 1):
  if sv[x] != 1:
    ans.append(x)
for i in range(len(ans)):
  if N == 2 * ans[i]:
    print(ans[i], ans[i])
  else:
    for j in range(i, len(ans)):
      if ans[i] + ans[j] == N:
        print(ans[i], ans[j])
      else:
        break
