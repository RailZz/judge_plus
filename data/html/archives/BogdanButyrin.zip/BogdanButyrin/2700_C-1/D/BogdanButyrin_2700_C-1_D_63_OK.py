def gcd(a, b):
  while a != 0 and b != 0:
    a, b = b, a % b
  return a + b

n1, n2 = map(int, input().split())
prod = n1 * n2
print(prod // gcd(n1, n2))
