def dfs(v, G, used, p):
    global cycle
    used[v] = 1
    for i in G[v]:
        if used[i] == 0:
            dfs(i, G, used, v)
        elif i != p:
            cycle = 'NO'
            

N, M = [int(i) for i in input().split()]
used = [0] * N
p = -1
cycle = 'YES'
G = [[] for i in range(N)]
for i in range(M):
    u, v = [int(i) for i in input().split()]
    u = u - 1
    v = v - 1
    G[u].append(v)
    G[v].append(u)
print(cycle)