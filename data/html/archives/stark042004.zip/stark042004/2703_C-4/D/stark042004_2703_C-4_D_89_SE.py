def dfs(v, col):
    color[v] = col
    global bad
    for i in range(0, len(gr[v])):
        if color(gr[v][i]) == 0:
            dfs(gr[v][i], 3 - col)
        elif color(gr[v][i]) == col:
            bad = 1


N, M = [int(i) for i in input().split()]
gr = [[] for i in range(N)]
for i in range(M):
    u, v = [int(i) for i in input().split()]
    u = u - 1
    v = v - 1
    gr[u].append(v)
    gr[v].append(u)
color = [0] * N
bad = 0
pasha = []
for i in range(N):
    if color[i] == 0:
        dfs(i, 1)
if bad == 1:
    print('NO')
else:
    print('YES')
    for i in range(N):
        if color[i] == 1:
            pasha.append(i + 1)
    print(*pasha)
