def dfs(v, G, used):
    global kol
    used[v] = 1
    for i in G[v]:
        if used[i] == 0:
            dfs(i, G, used)
            kol += 1


N, M = [int(i) for i in input().split()]
kol = 1
M -= 1
used = [0] * N
G = [[] for i in range(N)]
for i in range(N):
    a = [int(i) for i in input().split()]
    for j in range(N):
        if a[j] == 1:
            G[i].append(j)
dfs(M, G, used)
print(kol)