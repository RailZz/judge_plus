def f(t):
    p = 0
    for i in range(N):
        p+=a[i]//t 
    return p >= K


N, K= [int(i) for i in input().split()]
a = []
for i in range(N):
    s = int(input())
    a.append(s)

r = 10**18
l = 0 
while r-l>1:
    m = (r + l) // 2
    if f(m):
        l = m
    else:
        r = m
print(l)