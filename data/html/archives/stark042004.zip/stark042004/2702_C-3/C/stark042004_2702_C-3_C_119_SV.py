def f(a):
    return (a - a // K) * A + (a - a // M) * B >= X


A, K, B, M, X = [int(i) for i in input().split()]
l = 0
r = 10 ** 20
while r - l > 1:
    m = (r + l) // 2
    if f(m):
        r = m
    else:
        l = m
print(r)