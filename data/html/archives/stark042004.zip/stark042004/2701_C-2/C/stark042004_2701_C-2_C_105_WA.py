N, K = [int(i) for i in input().split()]
a = [int(i) for i in input().split()]
a.sort()
b = [int(i) for i in input().split()]
for i in range(K):
    l = 0
    r = N-1    
    g = b[i]
    while r-l>1:
        m = (r+l)//2
        if a[m]<=g:
            l=m
        else:
            r=m
    if a[l] == g:      
        print('YES')
    else:
        print('NO')