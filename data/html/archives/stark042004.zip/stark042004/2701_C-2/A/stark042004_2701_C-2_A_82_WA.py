x=2
i=1
n = int(input())
while x<n:
    x=x**2
    i+=1
print(i)
    
