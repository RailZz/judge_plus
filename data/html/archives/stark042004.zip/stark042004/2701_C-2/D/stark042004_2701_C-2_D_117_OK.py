from math import sqrt
C = float(input())
l = 0
r = 10 ** 10
for i in range(100):
    m = (l + r) / 2
    my = m ** 2 + sqrt(m)
    if my > C:
        r = m
    else:
        l = m
print(l)