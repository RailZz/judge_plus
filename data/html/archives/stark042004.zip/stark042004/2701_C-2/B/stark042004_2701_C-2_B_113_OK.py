from math import pi
from math import sin
a = float(input())
l = -pi/2
r = pi/2 
for i in range(100):
    m = (r+l)/2
    my = sin(m)
    if my < a:
        l=m
    else:
        r=m
print(l)