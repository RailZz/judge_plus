A, B = [int(i) for i in input().split()]
a = A
b = B
while a != 0 and b != 0:
    a, b = b, a % b
lcm = (A * B)// (a + b)
print(lcm)