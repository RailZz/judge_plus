a, b, c, d = [int(i) for i in input().split()]
if b == d:
    h = a + c
    while h != 0 and b != 0:
        h, b = b, h % b    
    print((a + c) // (h + b), d // (h + b))
else:
    j = b
    p = d    
    while b != 0 and d != 0:
        b, d = d, b % d
    lcm = (p * j) // (b + d)
    k = a * (lcm // j)
    s = c * (lcm // p)
    summa = k + s
    i = lcm
    while summa != 0 and i != 0:
        summa, i = i, summa % i
    m = (k + s) // (summa + i)
    n = lcm // (summa + i)
    print(m, n)