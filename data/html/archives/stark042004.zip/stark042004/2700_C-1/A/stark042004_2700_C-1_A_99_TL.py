def func (a):
    for i in range(2,a):
        if a%i == 0:
            s = 'composite'
            break
        if i == a-1:
            s = 'prime'
    return s
a = int(input())
if a == 2:
    print('prime')
else:
    print(func(a))