def solve (a):
    for i in range(2,a-1):
        if a%i == 0:
            print('composite')
            break
    else: print('prime')
    
a = int(input())
print(solve(a))