N = int(input())
mg = [ int(i) for i in input().split()]
for i in range(N-1):
    a = mg[i]
    b = mg[i+1]
    while a != 0 and b != 0:
        a, b = b, a % b
    mg[i+1] = a+b
print(mg[N-1])