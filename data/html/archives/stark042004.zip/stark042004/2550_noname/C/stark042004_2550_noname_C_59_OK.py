N = int(input())
b=0
for i in range(N):
    a = int(input())
    b+=a
print(b)    