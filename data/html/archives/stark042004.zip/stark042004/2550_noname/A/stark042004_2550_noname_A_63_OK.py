a = int(input())
print('The next number for the number', a ,'is', a+1,end='.\n')
print('The previous number for the number', a ,'is', a-1,end='.')