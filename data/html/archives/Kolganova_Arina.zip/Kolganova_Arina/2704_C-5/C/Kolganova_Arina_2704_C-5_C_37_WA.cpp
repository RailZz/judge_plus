#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> f(n);
    vector<int> k(n);
    for (int i = 0; i < n; ++i) {
        cin >> k[i];
    }
    f[0] = k[0];
    f[1] = min(f[0], 0) + k[1];
    f[2] = min(f[0], f[1]) + k[2];
    for (int i = 3; i < n; ++i) {
        f[i] = min(min(f[i - 1], f[i - 2]), f[i - 3]);
    }
    cout << f[n - 1];
    return 0;
}
