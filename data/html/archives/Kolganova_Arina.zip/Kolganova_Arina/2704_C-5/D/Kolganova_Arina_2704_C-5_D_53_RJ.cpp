#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
    int n, cur, par;
    cin >> n;
    vector<int> d(3 * n, 1e15);
    vector<int> p(3 * n, -1);
    vector<int> ans;
    d[1] = 0;
    for (int i = 1; i < n; ++i) {
        if (d[i] + 1 < d[i + 1]) {
            d[i + 1] = d[i] + 1;
            p[i + 1] = i;
        }
        if (d[i] + 1 < d[i * 2]) {
            d[i * 2] = d[i] + 1;
            p[i * 2] = i;
        }
        if (d[i] + 1 < d[i * 3]) {
            d[i * 3] = d[i] + 1;
            p[i * 3] = i;
        }
    }
    cur = n;
    while (cur != 1) {
        par = p[cur];

        if (cur == par + 1) {
            ans.push_back(1);
        } else if (cur == par * 2) {
            ans.push_back(2);
        } else {
            ans.push_back(3);
        }
        cur = par;
    }
    reverse(ans.begin(), ans.end());
    for (int i = 0; i < ans.size(); ++i) {
        cout << ans[i];
    }
    return 0;
}