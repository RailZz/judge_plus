#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
    int n, m, curx, cury;
    cin >> n >> m;
    vector<char> ans;
    vector<vector<int>> p(n, vector<int>(m));
    vector<vector<int>> d(n, vector<int>(m));
    vector<vector<int>> eat(n, vector<int>(m));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> eat[i][j];
        }
    }
    d[0][0] = eat[0][0];
    p[0][0] = 0;
    for (int j = 1; j < m; ++j) {
        d[0][j] = d[0][j - 1] + eat[0][j];
        p[0][j] = 2;
    }
    for (int i = 1; i < n; ++i) {
        d[i][0] = d[i - 1][0] + eat[i][0];
        p[i][0] = 1;
    }
    for (int i = 1; i < n; ++i) {
        for (int j = 1; j < m; ++j) {
            if (d[i - 1][j] > d[i][j - 1]) {
                d[i][j] = d[i - 1][j] + eat[i][j];
                p[i][j] = 1;
            } else {
                d[i][j] = d[i][j - 1] + eat[i][j];
                p[i][j] = 2;
            }
        }
    }
    cout << d[n - 1][m - 1] << '\n';

    curx = n - 1;
    cury = m - 1;
    while (curx != 0 || cury != 0) {
        if (p[curx][cury] == 1) {
            ans.push_back('D');
            curx -= 1;
        } else if (p[curx][cury] == 2) {
            ans.push_back('R');
            cury -= 1;
        }
    }

    reverse(ans.begin(), ans.end());
    for (int i = 0; i < ans.size(); ++i) {
        cout << ans[i] << " ";
    }
    return 0;
}
