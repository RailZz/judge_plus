#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> d(n + 1, vector<int>(m + 1));
    d[1][1] = 1;
    for (int i = 2; i <= n; ++i) {
        for (int j = 2; j <= m; ++j) {
           d[i][j] = d[i - 1][j - 2] + d[i - 2][j - 1];
        }
    }
    cout << d[n][m];
    return 0;
}