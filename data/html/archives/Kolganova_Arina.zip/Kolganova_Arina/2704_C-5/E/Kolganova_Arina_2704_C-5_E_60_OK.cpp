#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
    int n, m, cur, par;
    cin >> n >> m;
    int eat[20][20];
    int d[20][20];
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> eat[i][j];
        }
    }
    d[0][0] = eat[0][0];
    for (int i = 0; i < 1; ++i) {
        for (int j = 1; j < m; ++j) {
           d[i][j] = d[i][j - 1] + eat[i][j];
        }
    }
    for (int i = 1; i < n; ++i) {
        for (int j = 0; j < 1; ++j) {
            d[i][j] = d[i - 1][j] + eat[i][j];
        }
    }
    for (int i = 1; i < n; ++i) {
        for (int j = 1; j < m; ++j) {
            d[i][j] = min(d[i - 1][j], d[i][j - 1]) + eat[i][j];
        }
    }
    cout << d[n - 1][m - 1];
    return 0;
}