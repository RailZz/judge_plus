#include <iostream>
#include <cmath>

using namespace std;

int main(){
    int n,res=0;
    cin>>n;
    for(int i=2;i<=sqrt(n);++i)
        if(n%i==0) res++;
    res==0? cout<<"prime":cout<<"composite";
	return 0;
}
