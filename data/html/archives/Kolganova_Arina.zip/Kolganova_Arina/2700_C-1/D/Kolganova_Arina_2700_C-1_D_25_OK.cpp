#include <iostream>
#include <algorithm>

using namespace std;


int main(){
    int b, a,n,k;
    cin>>a>>b;
    n=a;
    k=b;
    while(a!=0){
        b=b%a;
        swap(a,b);
    }
    cout<<n/b*k;
	return 0;
}
