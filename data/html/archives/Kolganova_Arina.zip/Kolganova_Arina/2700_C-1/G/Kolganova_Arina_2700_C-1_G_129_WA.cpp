#include <iostream>
#include <vector>

using namespace std;

vector<int> primes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43};

int prost(int a){
    int res=0;
    for(int d=2;d*d<=a;d++){
       if(a%d==0) res++;
    } if(res==0)
         return 1;
      else return 0;

}




int main(){
    int n,m,k,otv1,otv2;
    cin>>n;
    for(int i:primes){
        int cur=i;
        if(prost(n-cur)==1 || cur==(n-cur)){
            otv1=cur;
            otv2=n-cur;
            break;
        }
    }
    cout<<otv1<<" "<<otv2;



	return 0;
}
