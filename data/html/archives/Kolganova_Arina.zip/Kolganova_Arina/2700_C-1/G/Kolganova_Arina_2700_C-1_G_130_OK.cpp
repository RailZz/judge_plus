#include <iostream>
#include <vector>

using namespace std;

vector<int> primes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 51, 53, 59, 61, 71, 73};

int prost(int a){
    int res=0;
    for(int d=2;d*d<=a;d++){
       if(a%d==0) res++;
    } if(res==0)
         return 1;
      else return 0;

}




int main(){
    int n,m,k,otv1,otv2;
    cin>>n;
    for(int i = 2; i < n; ++i){
        if(prost(i) && prost(n-i)==1){
            otv1=i;
            otv2=n-i;
            break;
        }
    }
    cout<<otv1<<" "<<otv2;



	return 0;
}
