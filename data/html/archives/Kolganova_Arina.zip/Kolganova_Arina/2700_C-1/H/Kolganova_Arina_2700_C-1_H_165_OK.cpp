#include <iostream>

using namespace std;

int main(){
    int n, res1, d, res2;
    cin >> n;
    for (int i = 219; i <= n; ++i) {
        res1 = 1;
        res2 = 1;
        d = 2;
        while (d * d <= i) {
            if (i % d == 0) {
                res1 += d;
                if (d != i / d) {
                    res1 += i / d;
                }
            }
            d++;
        }
        d = 2;
        while (d * d <= res1) {
            if (res1 % d == 0) {
                res2 += d;
                if (d != res1 / d) {
                    res2 += res1 / d;
                }
            }
            d++;
        }
        if (i == res2 && i < res1) {
            cout << i << " " << res1 << endl;
        }
    }
	return 0;
}
