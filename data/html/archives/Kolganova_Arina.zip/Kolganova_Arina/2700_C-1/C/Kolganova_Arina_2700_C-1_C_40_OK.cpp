#include <iostream>
#include <algorithm>

using namespace std;

int gcd(int a,int b){
   while(a!=0){
    b=b%a;
    swap(a,b);
   }
   return b;
}

int main() {
    int a[1000];
    int n;
    cin>>n;
    for(int i=0;i<n;++i)
        cin>>a[i];
    for (int i = 1; i < n; ++i) {
        a[0] = gcd(a[0], a[i]);
    }
    cout<<a[0];
}
