#include <iostream>
#include <vector>
using namespace std;

vector<int> primes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43};

int main(){
    int n,res1=0,res=1;
    cin>>n;
    vector<int> pw(n + 1);
    for (int i : primes) {
        int cur = i;
        while (cur <= n) {
            pw[i] += (n / cur);
            cur *= i;
        }
    }
    int ans = 1;
    for (int i = 0; i <= n; ++i) {
        ans *= (pw[i] + 1);
    }
    cout << ans << endl;
	return 0;
}
