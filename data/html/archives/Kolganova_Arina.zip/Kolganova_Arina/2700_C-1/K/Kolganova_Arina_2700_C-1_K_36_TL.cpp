#include <iostream>

using namespace std;


int main(){
    int n,res1=1,res2=0;
    cin>>n;
    for(int i=1;i<=n;i++)
        res1=res1*i;
    for(int i=1;i<=res1;i++)
        if(res1%i==0) res2++;
    cout<<res2;
	return 0;
}
