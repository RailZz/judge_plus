#include <iostream>
#include <algorithm>

using namespace std;


int main(){
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    int res1=b*d;
    a=a*d;
    c=c*b;
    int res2=a+c;
    b=res1;
    d=res2;
    while(b!=0){
        d=d%b;
        swap(b,d);
    }
    res1=res1/d;
    res2=res2/d;
    cout<<res2<<" "<<res1;
	return 0;
}
