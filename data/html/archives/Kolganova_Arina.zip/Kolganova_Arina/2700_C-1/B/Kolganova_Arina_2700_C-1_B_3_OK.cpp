#include <iostream>
#include <cmath>

using namespace std;

int main(){
    int n,d=2;
    cin>>n;
    while(d*d<=n){
      while(n%d==0){
        cout<<d<<" ";
        n/=d;}
      d++;}
    if(n!=1)
        cout<<n;



	return 0;
}
