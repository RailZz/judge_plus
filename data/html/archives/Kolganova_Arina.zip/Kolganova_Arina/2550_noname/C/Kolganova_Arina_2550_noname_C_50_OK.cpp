#include <iostream>

using namespace std;

int main (){
	int n,a;
	int res=0;
	cin>>n;
     for(int i=0;i<n;i++){
     	cin>>a;
     	res=res+a;
	 }
	 cout<<res;
	return 0;
}
