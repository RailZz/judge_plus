#include <iostream>

using namespace std;

int main (){
	int n, res=0;
	int a[5];
     for(int i=0;i<5;i++)
     	cin>>a[i];
     for(int i=1;i<4;i++)
        if(a[i]>a[i-1]+a[i+1]) res++;
	 cout<<res;
	return 0;
}
