#include <iostream>
#include <vector>
#include <cstdio>
using namespace std;

int main(){
	int n, x, res=0;
	vector<int> v;
	while (cin>>x) {
		v.push_back(x);
	}
	n = v.size();
	for(int i=1;i<n-1;i++)
		if(v[i]>v[i+1]&&v[i]>v[i-1]) res++;
    cout<<res;

}
