#include <iostream>

using namespace std;

int main() {
    unsigned long long A, mc1, B, W, H, mc2, N, m, l = 0, r = 100000000000;
    cin >> N >> A >> B >> W >> H;
    while (r - l > 1) {
        m = (l + r) / 2;
        mc1 = (H / (A + 2 * m)) * (W / (B + 2 * m));
        mc2 = (H / (B + 2 * m)) * (W / (A + 2 * m));
        if (mc1 < N && mc2 < N) {
            r = m;
        } else {
            l = m;
        }
    }
    cout << l;
    return 0;
}
