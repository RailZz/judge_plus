#include <iostream>
#include <vector>
#include <algorithm>


using namespace std;







int main(){
     unsigned long long res,kor,last,x,mc,y,n,k,m,l=0,r=100000000000;
     cin>>n>>k;
     vector<int> vec(n);
     for(int i=0;i<n;++i)
        cin>>vec[i];

     while(r-l>1){
        m=(l+r)/2;
        kor=1;
        last=0;
          for(int i=0;i<n;++i){
            if(vec[i]-vec[last]>=m){
                kor++;
                last=i;
            }}
            if(kor<k)
            r=m;
         else
            l=m;}
      cout<<r-1;
	return 0;
}
