#include <iostream>
#include <vector>
#include <algorithm>


using namespace std;


int kek(const vector<int>& vec, int q, int w){
    int res=0;
     for(int i=0;i<w;++i)
         res+=vec[i]/q;
     return res;
}


int main(){
     unsigned long long x,mc,y,n,k,m,l=0,r=10000000000001;
     cin>>n>>k;
     vector<int> vec(n);
     sort(vec.begin(),vec.end());
     for(int i=0;i<n;++i)
        cin>>vec[i];



      while(r-l>1){
         m=(r+l)/2;
         mc=kek(vec,m,n);
         if(mc<k)
            r=m;
         else
            l=m;}
       cout<<l;

	return 0;
}
