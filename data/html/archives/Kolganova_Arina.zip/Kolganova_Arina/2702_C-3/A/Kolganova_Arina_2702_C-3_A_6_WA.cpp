#include <iostream>


using namespace std;


int min(int q1, int q2){
     if(q1>q2)
        return q2;
     else return q1;
}


int main(){
     int x,y,n,m,l=0,r=2000;
     cin>>n>>x>>y;
     n--;
     while(r-l>1){
        m=(l+r)/2;
        if(m/x+m/y>=n)
            r=m;
        else
            l=m;}
    cout<<r+min(x,y);



	return 0;
}
