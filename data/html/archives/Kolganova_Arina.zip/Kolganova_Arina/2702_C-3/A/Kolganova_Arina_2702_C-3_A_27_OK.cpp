#include <iostream>
#include <cmath>
#include <algorithm>


using namespace std;



int main(){
     unsigned long long x,y,n,m,l=0,r=100000000000;
     cin>>n>>x>>y;
     n--;
     if(n==0)
       x>y?cout<<y:cout<<x;
     else{
        while(r-l>1){
          m=(l+r)/2;
          if(m/x+m/y>=n)
             r=m;
          else
            l=m;}
       cout<<r+min(x,y);}



	return 0;
}
