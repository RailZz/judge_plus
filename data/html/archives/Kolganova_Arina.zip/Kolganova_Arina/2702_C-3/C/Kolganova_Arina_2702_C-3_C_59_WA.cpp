#include <iostream>
#include <vector>
#include <algorithm>


using namespace std;





int main(){
     unsigned long long res,a,b,x,M,y,n,k,m,l=0,r=10000000000000000000;
     cin>>a>>k>>b>>m>>x;
      while(r-l>1){
        M=(l+r)/2;
        if((((M-M/k)*a)+((M-M/m)*b))>=x)
             r=M;
        else
             l=M;}
      cout<<r;
	return 0;
}
