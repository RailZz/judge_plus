#include <iostream>
#include <cmath>

using namespace std;

int main() {
    int n, m, w, h, res, r1, r2;
    cin >> w >> h >> n;
    res = sqrt(n);
    r1 = res * w;
    r2 = res * h;
    res = res * res;
    while (n - res != 0) {
        if (r2 >= r1) {
            r1 += w;
            res++;
        } else {
            r2 += h;
            res++;
        }
    }
    r1 >= r2 ? cout << r1: cout << r2;
    return 0;
}
