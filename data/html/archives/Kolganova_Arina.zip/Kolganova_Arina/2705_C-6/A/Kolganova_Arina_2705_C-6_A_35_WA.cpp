#include <iostream>
#include <cmath>

using namespace std;

int main() {
    int n, m, w, h, x1, x2, res, r1, r2, otv;
    cin >> w >> h >> n;
    res = sqrt(n);
    x1 = res;
    x2 = res;
    r1 = x1 * w;
    r2 = x2 * h;
    otv = x1 * x2;
    while (n > otv) {
        if (r1 >= r2) {
            r2 += h;
            x2++;
        } else {
            r1 += w;
            x1++;
        }
        otv = x1 * x2;
    }
    r1 >= r2 ? cout << r1: cout << r2;
    return 0;
}
