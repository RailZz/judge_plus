#include <iostream>
#include <cmath>

using namespace std;

int main(){
    int n, res=0;
    cin>>n;
    cout<<ceil(log(n)/log(2));
return 0;
}

