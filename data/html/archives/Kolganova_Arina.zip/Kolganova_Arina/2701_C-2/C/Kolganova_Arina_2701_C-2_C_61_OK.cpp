#include <iostream>
#include <vector>
using namespace std;



int main(){
    int n,m,k,res,y,l,r;
    cin>>n>>k;
    vector<int> pw1(n);
    vector<int> pw2(k);
    for(int i=0;i<n;++i)
       cin>>pw1[i];
    for(int i=0;i<k;++i)
       cin>>pw2[i];


    for(int i=0;i<k;++i){
      y=pw2[i];
      l=-1;
      r=n-1;
      while(r-l>1){
        m=(l+r)/2;
       if(pw1[m]>=y)
         r=m;
       else l=m;}
     if(pw1[r]==y)
        cout<<"YES"<<endl;
     else
        cout<<"NO"<<endl;
    // cout<<r<<endl;
     }



	return 0;
}
