#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main(){
    float r,n,m,l, res;
    cin>>n;
    float pi=3.14159265359;
    l=-pi/2;
    r=pi/2;
    for(int i=0;i<70;++i){
        m=(l+r)/2;
        if(sin(m)>n)
            r=m;
        else
            l=m;
    }
    cout<<fixed<<setprecision(6)<<r;


return 0;
}

