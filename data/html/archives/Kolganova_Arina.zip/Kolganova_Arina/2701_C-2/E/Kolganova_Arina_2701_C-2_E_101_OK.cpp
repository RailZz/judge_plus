#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;



int main(){
    int n,m,k,res,y,l,r,otv1,otv2;
    cin>>n;
    vector<int> pw1(n);
      for(int i=0;i<n;++i)
        cin>>pw1[i];
    cin>>k;
    vector<int> pw2(k);
      for(int i=0;i<k;++i)
         cin>>pw2[i];

    sort(pw1.begin(), pw1.end());



     for(int i=0;i<k;++i){
        y=pw2[i];
        l=-1;
        r=n-1;
        res=1;

           while(r-l>1){
              m=(l+r)/2;
              if(pw1[m]>=y)
                r=m;
              else
                l=m;
           }
           otv2=r;
        if(pw1[r]!=y){
            cout<<"0"<<" ";
        continue;}
         l=0;
         r=n;

           while(r-l>1){
             m=(l+r)/2;
               if(pw1[m]>y)
                 r=m;
               else
                 l=m;
           } otv1=l;


         res=res+(otv1-otv2);

       cout<<res<<" ";}



	return 0;
}
