#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;



int main(){
    double n,m,k,res,y,r,l;
    cin>>n;
    l=0;
    r=n;
    for(int i=0;i<70;++i){
        m=(l+r)/2;
        if(pow(m,2)+sqrt(m)>n)
            r=m;
        else
            l=m;
    }
    cout<<fixed<<setprecision(6)<<l;





	return 0;
}
