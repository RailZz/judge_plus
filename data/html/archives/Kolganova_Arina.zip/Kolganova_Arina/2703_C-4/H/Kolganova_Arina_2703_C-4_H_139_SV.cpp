#include <iostream>
#include <vector>

using namespace std;

vector<int> dx = {-1, 0, 1, 0};
vector<int> dy = {0, 1, 0, -1};

int good(const vector<vector<char>> &field, int x, int y, int n) {
    if (x >= 0 && y >=0 && x < n && y < n && field[x][y] == '.') {
        return 1;
    } else {
        return 0;
    }
}

void dfs(const vector<vector<char>> &field, vector<vector<int>> &used, int x, int y, int n, int &ans) {
    used[x][y] = 1;
    ans++;
    for (int i = 0; i < 4; ++i){
        if (good (field, x + dx[i], y + dy[i], n) && used[x + dx[i]][y + dy[i]] == 0) {
            dfs(field, used, x + dx[i], y + dy[i], n, ans);
        }
    }
}

int main() {
    long long n, m, x, y, res = 0;
    cin >> n;
    vector<vector<char>> field(n, vector<char>(n));
    vector<vector<int>> used(n, vector<int>(n));
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < n; ++j){
            cin >> field[i][j];
        }
    }
    cin >> x >> y;
    x--;
    y--;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            used[i][j] = 0;
        }
    }
    int ans = 0;
    dfs(field, used, x, y, n, ans);
    cout << ans;

    return 0;
}
