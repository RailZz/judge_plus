#include <iostream>
#include <vector>

using namespace std;

void dfs(vector<vector<int>> &gr, vector<int> &used, int v) {
    used[v] = 1;
    for (int i = 0; i < gr[v].size(); ++i) {
        if (used[gr[v][i]] == 0) {
            dfs(gr, used, gr[v][i]);
        }
    }
}

int main() {
    long long n, s, h, res = 0;
    cin >> n >> s;
    s--;
    vector<vector<int>> gr(n);
    vector<int> used(n);
    for (int i = 0; i < n; ++i) {
        used[i] = 0;
    }
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> h;
            if (h == 1) {
                gr[i].push_back(j);
            }
        }
    }
    dfs(gr, used, s);
    for (int i = 0; i < n; ++i) {
        if (used[i] == 1) {
            res++;
        }
    }
    cout << res;
return 0;
}