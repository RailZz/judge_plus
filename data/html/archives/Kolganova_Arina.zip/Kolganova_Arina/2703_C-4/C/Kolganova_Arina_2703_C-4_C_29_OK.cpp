#include <iostream>
#include <vector>

using namespace std;

int main(){
    int n, m, h, res, sum1 = 0, sum2 = 0;
    cin >> n;
    int gr[100][100];
    vector<int> used1(n);
    vector<int> used2(n);
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < n; ++j){
            cin >> gr[i][j];
        }
    }
    for (int i = 0; i < n; ++i){
        res = 0;
        for (int j = 0; j < n; ++j){
            if (gr[j][i] == 1){
                res++;
            }
        }
        if (res == 0){
            used1[sum1] = i + 1;
            sum1++;
        }
    }
    for (int i = 0; i < n; ++i){
        res = 0;
        for (int j = 0; j < n; ++j){
            if (gr[i][j] == 1){
                res++;
            }
        }
        if (res == 0){
            used2[sum2] = i + 1;
            sum2++;
        }
    }
    cout << sum1 << endl;
    for (int i = 0; i < sum1; ++i){
        cout << used1[i] << endl;
    }
    cout << sum2 << endl;
    for (int i = 0; i < sum2; ++i){
        cout << used2[i] << endl;
    }

    return 0;
}