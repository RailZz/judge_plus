#include <iostream>
#include <vector>

using namespace std;

int main() {
    long long n, m, u, v, res = 0;
    cin >> n >> m;
    vector <vector <int>> gr(n);
    for (int i = 0; i < m; ++i) {
        cin >> u >> v;
        u--;
        v--;
        gr[u].push_back(v);
        gr[v].push_back(u);
    }

    for (int i = 0; i < n; ++i){
        cout << gr[i].size() << " ";
    }
    return 0;
}
