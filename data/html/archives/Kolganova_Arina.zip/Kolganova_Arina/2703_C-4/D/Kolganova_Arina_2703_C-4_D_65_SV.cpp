#include <iostream>
#include <vector>

using namespace std;

void dfs (vector<vector<int>> &gr, vector<int> &color, long long &bad, int v, int col) {
    color[v] = col;
    for (int i = 0; i < gr[v].size(); ++i) {
        if (color[gr[v][i]] == 0) {
            dfs(gr, color, bad, gr[v][i], 3 - col);
        } else if (color[gr[v][i]] == col) {
            bad = 1;
        }
    }
}

int main() {
    long long n, m, v, u, bad = 0;
    cin >> n >> m;
    vector<vector<int>> gr(n);
    vector<int> color(n);
    for (int i = 0; i < n; ++i) {
        color[i] = 0;
    }
    for (int i = 0; i < m; ++i) {
        cin >> u >> v;
        u--;
        v--;
        gr[u].push_back(v);
        gr[v].push_back(u);
    }
    for (int i = 0; i < n; ++i) {
        if (color[i] == 0) {
            dfs(gr, color, bad, i, 1);
        }
    }
    if (bad == 1) {
        cout << "NO" << endl;
    } else {
        cout << "YES" << endl;
        for (int i = 0; i < n; ++i) {
            if (color[i] == 1) {
                cout << i + 1 << ' ';
            }
        }
    }
    return 0;
}