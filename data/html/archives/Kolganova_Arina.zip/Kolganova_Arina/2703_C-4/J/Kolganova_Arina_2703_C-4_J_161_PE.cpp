#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>

using namespace std;

int main() {
    long long n, v, s, h, t, cur_v;
    cin >> n;
    vector<vector<int>> gr(n);
    vector<int> d(n);
    vector<int> p(n);
    for (int i = 0; i < n; ++i) {
        d[i] = 1e8;
    }
    for (int i = 0; i < n; ++i) {
        p[i] = -1;
    }
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> h;
            if (h == 1) {
                gr[i].push_back(j);
            }
        }
    }
    cin >> s >> t;
    s--;
    t--;
    d[s] = 0;
    queue<int> q;
    q.push(s);
    while (q.size() > 0) {
        v = q.front();
        q.pop();
        for (auto i : gr[v]) {
            if (d[i] > d[v] + 1) {
                d[i] = d[v] + 1;
                q.push(i);
                p[i] = v;
            }
        }
    }
    cur_v = t;
    vector<int> ans;
    while (cur_v != -1) {
        ans.push_back(cur_v);
        cur_v = p[cur_v];
    }
    if (d[t] == 1e10) {
        cout << "-1";
    } else {
        cout << d[t] << endl;
        if (d[t] != 0) {
            reverse(ans.begin(), ans.end());
            for (int i = 0; i < ans.size(); ++i) {
                cout << ans[i] + 1 << " ";
            }
        }
    }
    return 0;
}
