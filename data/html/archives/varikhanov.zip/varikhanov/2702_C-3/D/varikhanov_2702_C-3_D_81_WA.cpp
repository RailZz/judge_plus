#include <iostream>

using namespace std;

int main()
{
    int n;
    int k;
    cin>>n>>k;
    int mas[n];
    for(int i=0;i<n;i++)
    {
        cin>>mas[i];
    }
    int m;
    int l=-1;
    int r=mas[n-1];
    while(r-l>1)
    {
        m=(r+l)/2;
        if(r-m>=mas[n-1]-m)
        {
            r=m;
        }
        else
        {
            l=m;
        }
    }
    cout<<r;
    return 0;
}
