#include <iostream>

using namespace std;
int min(int a,int b)
{
    int min=0;
    if(a>b)
    {
        min=b;
    }
    else
    {
        min=a;
    }
    return(min);
}
int main()
{
    int n;
    cin>>n;
    n--;
    int x,y;
    cin>>x>>y;
    int l=0;
    int r=10000000000;
    int m;
    while(r-l>1)
    {
        m=(r+l)/2;
        if((m/x+m/y)>=n)
        {
            r=m;
        }
        else
        {
            l=m;
        }
    }
    if(n==0)
    {
      cout<<min(x,y);
    }
    else
    {
      cout<<r+min(x,y);
    }
    return 0;
}
