#include <iostream>

using namespace std;
int min(int a,int b)
{
    int min=0;
    if(a>b)
    {
        min=b;
    }
    else
    {
        min=a;
    }
    return(min);
}
int main()
{
    int n;
    cin>>n;
    n--;
    int x,y;
    cin>>x>>y;
    int l=0;
    int r=10000000;
    int m;
    while(r-l>1)
    {
        if(n==1)
        {
            r=min(x,y);
            break;
        }
        m=(r+l)/2;
        if((m/x+m/y)>=n)
        {
            r=m;
        }
        else
        {
            l=m;
        }
    }
    cout<<r+min(x,y);
    return 0;
}
