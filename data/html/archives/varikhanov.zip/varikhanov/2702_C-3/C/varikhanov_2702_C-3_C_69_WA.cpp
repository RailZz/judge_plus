#include <iostream>

typedef unsigned long long ll;

ll trees_cut(ll mid,ll a,ll k,ll b,ll m)
{
    ll trees1;
    ll trees2;
    trees1=a*mid-mid/k*a;
    trees2=b*mid-mid/m*b;
    ll trees=trees1+trees2;
    return(trees);
}
using namespace std;
int main()
{
    ll a,k,b,m,x;
    cin>>a>>k>>b>>m>>x;
    ll l=1;
    ll r=1e19 / (a + b);//10^19/a+b(������������)
    ll mid;
    while(r-l>1)
    {
        mid=(r+l)/2;
        ll trees=trees_cut(mid,a,k,b,m);
        if(trees>=x)
        {
            r=mid;
        }
        else
        {
            l=mid;
        }
    }
    cout<<r;
    return 0;
}
