#include <iostream>
int trees_cut(int mid,int a,int k,int b,int m)
{
    int trees1;
    int trees2;
    trees1=a*mid-mid/k*a;
    trees2=b*mid-mid/m*b;
    int trees=trees1+trees2;
    return(trees);
}
using namespace std;
int main()
{
    int a,k,b,m,x;
    cin>>a>>k>>b>>m>>x;
    int l=1;
    int r=100000000000;
    int mid;
    while(r-l>1)
    {
        mid=(r+l)/2;
        int trees=trees_cut(mid,a,k,b,m);
        if(trees>=x)
        {
            r=mid;
        }
        else
        {
            l=mid;
        }
    }
    cout<<r;
    return 0;
}
