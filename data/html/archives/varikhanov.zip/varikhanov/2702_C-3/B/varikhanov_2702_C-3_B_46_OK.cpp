#include <iostream>
#include <algorithm>
using namespace std;
int mas[1000000];
int get_count(int q,int n)
{
    int sum=0;
    for(int i=0;i<n;i++)
    {
        sum=sum+mas[i]/q;
    }
    return(sum);
}

int main()
{
    int n,k;
    cin>>n>>k;
    int l=0;
    int r=10000000000;
    for(int i=0;i<n;i++)
    {
        cin>>mas[i];
    }
    sort(mas,mas+n);
    int m;
    int mc;
    while(r-l>1)
    {
        m=(r+l)/2;
        mc=get_count(m,n);
        if(mc<k)
        {
            r=m;
        }
        else
        {
            l=m;
        }
    }
    cout<<l;

    return 0;
}
