#include <iostream>
#include <stdlib.h>
using namespace std;

int main()
{

    int a;
    cin>>a;
    int num=0;
    for(int i=1;i<abs(a);i++)
    {
        if(a%i==0)
        {
            num++;
        }
    }
    if(num>1)
    {
        cout<<"composite";
    }
    else
        cout<<"prime";
    return 0;
}
