#include <iostream>

using namespace std;

int main()
{
    int n,k;
    cin>>n>>k;
    int mas1[n];
    int mas2[k];
    int z=0;
    for(int i=0;i<n;i++)
    {
        cin>>mas1[i];
    }
    for(int i=0;i<k;i++)
    {
        cin>>mas2[i];
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<k;j++)
        {
            if(mas1[j]==mas2[i])
            {
                cout<<"YES"<<endl;
                z=1;
                i++;
            }

              if(z==0)
                {
                  cout<<"NO"<<endl;
                  i++;
                }
            z=0;
        }
    }
    return 0;
}
