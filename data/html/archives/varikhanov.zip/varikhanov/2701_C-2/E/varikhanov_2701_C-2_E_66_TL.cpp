#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int mas1[n];
    for(int i=0;i<n;i++)
    {
        cin>>mas1[i];
    }
    int m;
    cin>>m;
    int mas2[m];
    int num=0;
    for(int i=0;i<m;i++)
    {
        cin>>mas2[i];
    }
    for(int i=0;i<m;i++)
    {
        int r=n-1;
        int l=0;
        while(r-l>=0)
        {
            if(mas2[i]==mas1[r])
            {
                num++;
            }
            if(mas2[i]==mas1[l])
            {
                num++;
            }
            if(r==l && mas1[r]==mas2[i])
            {
                num--;
            }
            r--;
            l++;
        }
        cout<<num<<" ";
        num=0;
    }
    return 0;
}
