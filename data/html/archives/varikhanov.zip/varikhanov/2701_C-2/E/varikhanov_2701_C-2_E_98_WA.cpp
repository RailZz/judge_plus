#include <iostream>
#include <cstdlib>
#include <algorithm>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int mas1[n];
    for(int i=0;i<n;i++)
    {
        cin>>mas1[i];
    }
    sort(mas1, mas1 + n);
    int m;
    cin>>m;
    int mas2[m];
    int num=0;
    for(int i=0;i<m;i++)
    {
        cin>>mas2[i];
    }
    //����������
    for(int i=0;i<m;i++)
    {
        int r=n-1;
        int l=-1;
        int z;
        while(r-l>1)
        {
            z=(l+r)/2;
            if(mas1[z]>=mas2[i])
            {
                r=z;
            }
            else
            {
                l=z;
            }
        }
        if(mas1[r]!=mas2[i])
        {
            r=n;
        }
        num=r;
        r=n;
        l=0;
        while(r-l>1)
        {
            z=(l+r)/2;
            if(mas1[z]>mas2[i])
            {
                r=z;
            }
            else
            {
                l=z;
            }
        }
        num=l-num+1;

        cout<<num<<" ";
        num=0;
    }
    return 0;
}
