#include <iostream>
#include <cmath>
using namespace std;
double func(double x)
{
    double c=x*x+sqrt(x);
    return(c);
}
int main()
{
    double c;
    cin>>c;
    double l=0;
    double r=c;
    double m;
    for(int i=0;i<70;i++)
    {
        m=(l+r)/2;
        if(func(m)<c)
           {
               l=m;
           }
            else
            {
                r=m;
            }
    }
    cout.precision(20);
    cout<<l;
    return 0;
}
