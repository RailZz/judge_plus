#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int l=0;
    int m;
    double num=ceil(log2(n));
    cout<<num;
    return 0;
}
