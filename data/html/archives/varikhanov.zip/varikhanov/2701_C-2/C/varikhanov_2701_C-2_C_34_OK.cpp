#include <iostream>

using namespace std;

int main()
{
    int n,k;
    cin>>n>>k;
    int mas1[n];
    int mas2[k];
    for(int i=0;i<n;i++)
    {
        cin>>mas1[i];
    }
    for(int i=0;i<k;i++)
    {
        cin>>mas2[i];
    }

    int m;
    for(int i=0;i<k;i++)
    {
        int l=0;
        int r=n;
        while(r-l>1)
        {
            m=(l+r)/2;
            if(mas1[m]>mas2[i])
            {
                r=m;
            }
            else
            {
                l=m;
            }
        }
        if(mas1[l]==mas2[i])
        {
            cout<<"YES"<<endl;
        }
        else
            cout<<"NO"<<endl;
    }
    return 0;
}
