#include <iostream>
#include <cmath>
#define _USE_MATH_DEFINES
using namespace std;

int main()
{
    double a;
    cin>>a;
    double r=M_PI/2;
    double l=-M_PI/2;
    double m;
    while(r-l>0.00001)
    {
        m=(l+r)/2;
        if(sin(m)<a)
        {
            l=m;
        }
        else
        {
            r=m;
        }
    }

    cout<<l;
    return 0;
}
