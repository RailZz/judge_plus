#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double a;
    cin>>a;
    double arcsin=asin(a);
    cout<< arcsin;
    return 0;
}
