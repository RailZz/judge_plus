#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n, a1, k, b, m;
    cin >> n >> a1 >> k >> b >> m;
    int a[n];
    a[0] = a1;
    for (int i = 1; i < n; i++)
    {
        a[i] = (k * a[i - 1] + b) % m;
    }
    int inf = 1000000000;
    vector<int> d(n + 1, inf);
    for (int i = 0; i < n; i++)
    {
        int pos = lower_bound(d.begin(), d.end(), a[i]) - d.begin();
        d[pos] = a[i];
    }
    int ans;
    for (int i = 0; d[i] != inf; i++)
    {
        ans = i;
    }
    cout << ans + 1;
    return 0;
}
