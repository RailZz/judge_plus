#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n;
    cin >> n;
    vector<int> d(n + 1, 0);
    d[n] = 1;
    d[n - 1] = 1;
    d[n - 2] = 2;
    for (int i = n - 3; i >= 0; i--)
    {
        d[i] = d[i + 1] + d[i + 2] + d[i + 3];
    }
    cout << d[0];
    return 0;
}
