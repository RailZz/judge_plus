#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n;
    cin >> n;
    vector<int> d;
    if (n != 1)
    {
        d.resize(n + 1, 0);
        d[n] = 1;
        d[n - 1] = 1;
        d[n - 2] = 2;
    } else {
        d.resize(1);
        d[0] = 1;
    }
    for (int i = n - 3; i >= 0; i--)
    {
        d[i] = d[i + 1] + d[i + 2] + d[i + 3];
    }
    cout << d[0];
    return 0;
}
