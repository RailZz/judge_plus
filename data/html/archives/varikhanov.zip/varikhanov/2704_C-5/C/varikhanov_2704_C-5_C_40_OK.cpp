#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n;
    cin >> n;
    vector<int> k(n);
    vector<int> d(n, 0);
    for (int i = 0; i < n; i++)
    {
        cin >> k[i];
    }
    d[0] = k[0];
    d[1] = k[1];
    for (int i = 2; i < n; i++)
    {
        d[i] = k[i] + min(d[i - 1], d[i - 2]);
    }
    cout << d[n - 1];
    return 0;
}
