#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int n, m;
vector<vector<int>> d;
vector<vector<int>> k;

int get(int i, int j) {
    if (i >= 0 && j >= 0 && i < n && j < m) {
        return d[i][j];
    }
    return 0;
}

vector<vector<int>> field;

int main()
{
    cin >> n >> m;
    d.resize(n,vector<int>(m));
    k.resize(n,vector<int>(m));
    char p[n][m];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> k[i][j];
        }
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            d[i][j] = max(get(i - 1, j), get(i, j - 1)) + k[i][j];
            if (get(i - 1, j) == max(get(i - 1, j), get(i, j - 1)))
            {
                p[i][j] = 'D';
            } else {
                p[i][j] = 'R';
            }
        }
    }
    cout << d[n - 1][m - 1] << endl;
    vector<char> answer;
    for (int i = n - 1, j = m - 1; i >= 0 && j >= 0;)
    {
        answer.push_back(p[i][j]);
        if(p[i][j] == 'D')
        {
            i--;
        } else {
            j--;
        }
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cout << d[i][j] << " ";
        }
        cout << endl;
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cout << p[i][j] << " ";
        }
        cout << endl;
    }
    answer.resize(answer.size() - 1);
    reverse(answer.begin(), answer.end());
    for (int i = 0; i < answer.size(); i++)
    {
        cout << answer[i] << " ";
    }
    return 0;
}
