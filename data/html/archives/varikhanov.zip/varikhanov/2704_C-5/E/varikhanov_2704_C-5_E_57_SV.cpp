#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n, m;
    cin >> n >> m;
    int d[n + 1][m + 1];
    int k[n][m];
    vector<vector<int>> p(n, vector<int>(m));
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            d[i][j] = 0;
            cin >> k[i][j];
        }
    }
    for (int i = 0; i < n + 1; i++)
    {
        for (int j = 0; j < 1; j++)
        {
            d[i][j] = 0;
        }
    }
    for (int i = 0; i < 1; i++)
    {
        for (int j = 0; j < m + 1; j++)
        {
            d[i][j] = 0;
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            d[i][j] = min(d[i - 1][j],d[i][j - 1]) + k[i][j];
        }
    }
    cout << d[n - 1][n - 1] + k[0][0];
    return 0;
}
