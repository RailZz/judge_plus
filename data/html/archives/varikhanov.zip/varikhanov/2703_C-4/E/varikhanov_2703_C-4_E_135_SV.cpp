#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<vector<int>> gr;
vector<int> used;
int cycle = 0;

int dfs(int v, int p)
{
    used[v]=1;
    for (int i = 0; i < gr.size(); i++)
    {

        if (gr[v][i] == 0)
        {
            dfs(used[gr[v][i]], v);
        } else {
            if (v != p)
            {
               cycle = 1;
            }
        }
    }
}

int main()
{
    int n, m;
    cin >> n >> m;
    bool tree = true;
    gr.resize(n);
    for (int i = 0; i < m; i++)
    {
        int u, v;
        cin >> u >> v;
        v--;
        u--;
        gr[u].push_back(v);
        gr[v].push_back(u);
    }
    used.resize(n, 0);
    dfs(0, -1);
    if (cycle == 1)
    {
        cout << "NO";
    } else{
        cout << "YES";
    }
    return 0;
}
