#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<vector<int>> gr;

int main()
{
    int n, m;
    cin >> n >> m;
    gr.resize(n);
    int u, v;
    for (int i = 0; i < m; i++)
    {
        cin >> u >> v;
        u--;
        v--;
        gr[u].push_back(v);
        gr[v].push_back(u);
    }
    if (n - m == 1)
    {
        cout << "YES";
    } else {
        cout << "NO";
    }

    return 0;
}
