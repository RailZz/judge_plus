#include <iostream>
#include <vector>

using namespace std;

vector<vector<int>> gr;
vector<int> color;
bool bad = false;
int dfs(int v, int col)
{
    color[v] = col;
    for (int i = 0; i < gr[v].size(); i++)
    {
        if (color[gr[v][i]] == 0)
        {
            dfs(gr[v][i],3 - col);
        }
        else if (color[gr[v][i]] == col)
        {
            bad = true;
        }
    }
}

int main()
{
    int  n,m;
    //n - number of VIPs
    //m = number of pairs
    cin >> n >> m;
    gr.resize(n);
    color.resize(n);
    int v,u;
    for (int i = 0; i < m; i++)
    {
        cin >> v >> u;
        v--;
        u--;
        gr[u].push_back(v);
        gr[v].push_back(u);
    }
    for (int i = 0; i < n; i++)
    {
        if (color[i] == 0)
        {
            dfs(i,1);
        }
    }
    if (bad == false)
    {
        cout << "YES" << endl;
        for (int i = 0; i < color.size(); i++)
        {
            if (color[i] == 1)
            {
                cout << i+1 << " ";
            }
        }
    }
    else
    {
        cout << "NO";
    }
    return 0;
}


