#include <iostream>
#include <vector>

using namespace std;

vector<int> used;
int sum = 0;
int n;
vector<vector<int>> gr;
void dfs(int v)
{
    used[v] = 1;
    sum++;
    for (int i = 0; i < gr[v].size(); i++)
    {
        if (used[gr[v][i]] == 0)
        {
            dfs(gr[v][i]);
        }
    }
}

int main()
{
    int s;
    cin >> n >> s;
    s--;
    gr.resize(n);
    used.resize(n, 0);
    int h;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> h;
            if (h == 1)
            {
                gr[i].push_back(j);
            }
        }
    }
    dfs(s);
    cout << sum;
    return 0;
}
