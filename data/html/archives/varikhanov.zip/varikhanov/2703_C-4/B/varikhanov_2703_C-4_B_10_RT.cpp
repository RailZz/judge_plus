#include <iostream>
#include <vector>

using namespace std;

vector<int> used;
int sum = 1;
int n;
vector< vector< int > >gr;
void dfs(int number)
{
    used[number] = 1;
    for(int i = 0; i < n; i++)
    {
        if (gr[number][i]==0)
        {
            sum++;
            dfs(gr[number][i]);
        }
    }
}

int main()
{
    int s;
    cin >> n >> s;
    gr.resize(n);
    used.resize(n);
    for (int i = 0; i < n; i++)
    {
        used[i] = 0;
    }
    int h;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> h;
            if ( h == 1)
            {
                gr[i].push_back(j);
            }
        }
    }
    for (int i = 0; i < n; i++)
    {
        dfs(i);
    }
    cout << sum;
    return 0;
}
