#include <iostream>
#include <vector>

using namespace std;

vector<vector<bool>> used;
vector<vector<char>> field;
int dx[4] = {-1, 0, 1, 0};
int dy[4] = {0, 1, 0, -1};
int S = 0;

bool good (int x, int y, int n)
{
    if (x >= 0 && y >= 0 && x < n && y < n && field[x][y] == '.')
    {
        return (true);
    } else {
    return (false);
    }
}

int dfs(int x, int y, int n)
{
    S++;
    used[x][y] = true;
    for (int i = 0; i < 4; i++)
    {
        if (good(x + dx[i], y + dy[i], n) && used[x + dx[i]][y + dy[i]] == false)
        {
            dfs(x + dx[i], y + dy[i], n);
        }
    }
}

int main()
{
    int n;
    cin >> n;
    field.resize(n, vector<char>(n));
    used.resize(n, vector<bool>(n));
    for (int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            cin >> field[i][j];
        }
    }
    int x, y;
    cin >> x >> y;
    x--;
    y--;
    dfs(x, y, n);
    cout << S;
    return 0;
}
