#include <iostream>
#include <vector>

using namespace std;

vector<vector<char>> paper;
vector<vector<bool>> used;
int dx[4] = {-1, 0, 1, 0};
int dy[4] = {0, 1, 0, -1};

bool good(int x, int y, int m, int n)
{
    if (x >= 0 && y >= 0 && x < m && y < n && paper[x][y] == '#')
    {
        return true;
    } else {
        return false;
    }
}

int dfs(int x, int y, int m, int n)
{
    used[x][y] = true;
    for (int i = 0; i < 4; i++)
    {
        if (good(x + dx[i], y + dy[i], m, n) && used[x + dx[i]][y + dy[i]] == false)
        {
            dfs(x + dx[i], y + dy[i], m, n);
        }
    }
}

int main()
{
    int n, m;
    cin >> m >> n;
    paper.resize(m, vector<char>(n));
    used.resize(m, vector<bool>(n, false));
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> paper[i][j];
        }
    }
    int pieces = 0;
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (used[i][j] == false && paper[i][j] == '#')
            {
                pieces++;
                dfs(i, j, m, n);
            }
        }
    }
    cout << pieces;
    return 0;
}
