#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<vector<int>> gr;
vector<int> used;
vector<int> starts_of_components;
vector<vector<int>> components;

int dfs(int v, int t)
{
    used[v] = 1;
    components[t].push_back(v);
    for (int i = 0; i < gr[v].size(); i++)
    {
        if (used[gr[v][i]] == 0)
        {
            dfs(gr[v][i], t);
        }
    }
}

int main()
{
    int n, m;
    cin >> n >> m;
    int u, v;
    gr.resize(n);
    used.resize(n, 0);
    for (int i = 0; i < m; i++)
    {
        cin >> u >> v;
        u--;
        v--;
        gr[u].push_back(v);
        gr[v].push_back(u);
    }
    for (int i = 0; i < n; i++)
    {
        if(used[i] != 1)
        {
            components.resize(components.size() + 1);
            int t = components.size() - 1; //����� ����������
            dfs(i, t);
        }
    }
    cout << components.size() << endl;
    for (int i = 0; i < components.size(); i++)
    {
        sort(components[i].begin(), components[i].end());
        cout << components[i].size() << endl;
        for(int j = 0; j < components[i].size(); j++)
        {
            cout << components[i][j] + 1 << " ";
        }
        cout << endl;
    }
    return 0;
}
