#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n;
    cin >> n;
    vector<vector<int>> gr(n);
    bool source[n];
    bool drain[n];
    for (int i = 0; i < n; i++)
    {
        source[i] = true;
        drain[i] = true;
    }
    int h;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> h;
            if (h == 1)
            {
                gr[i].push_back(j);
            }
        }
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < gr[i].size(); j++)
        {
            drain[i] = false;
            source[gr[i][j]] = false;
        }
    }
    int sources = 0;
    for (int i = 0; i < n; i++)
    {
        sources += source[i];
    }
    cout << sources << endl;
    for (int i = 0; i < n; i++)
    {
        if (source[i] == true)
        {
            cout << i + 1 << endl;
        }
    }
    int drains = 0;
    for (int i = 0; i < n; i++)
    {
        drains += drain[i];
    }
    cout << drains << endl;
    for (int i = 0; i < n; i++)
    {
        if (drain[i] == true)
        {
            cout << i + 1 << endl;
        }
    }
    return 0;
}
