#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main()
{
    int n;
    cin >> n;
    vector<vector<int>> gr(n);
    int h;
    for (int i = 0; i < n; i++)
    {
        for ( int j = 0; j < n; j++)
        {
            cin >> h;
            if (h == 1)
            {
                gr[i].push_back(j);
            }
        }
    }
    int start, finish;
    cin >> start >> finish;
    start--;
    finish--;
    int d[n];
    int parents[n];
    for (int i = 0; i < n; i++)
    {
        parents[i] = -1;
        d[i] = 1000000000;
    }
    d[start] = 0;
    queue<int> q;
    q.push(start);
    int v;
    while (q.size() > 0)
    {
        v = q.front();
        q.pop();
        for (auto i : gr[v])
        {
            if (d[i] > d[v] + 1)
            {
                d[i] = d[v] + 1;
                q.push(i);
                parents[i] = v;
            }
        }
    }
    int cur_v = finish;
    vector<int> ans;
    while (cur_v != -1)
    {
        ans.push_back(cur_v);
        cur_v = parents[cur_v];
    }
    if (d[finish] != 1000000000)
    {
        if (ans.size() == 1)
        {
            cout << 0;
        } else {
            cout << ans.size() - 1 << endl;
            for (int i = ans.size() - 1; i >= 0; i--)
            {
                cout << ans[i] + 1 << " ";
            }
        }
    } else {
    cout << -1;
    }
    return 0;
}
