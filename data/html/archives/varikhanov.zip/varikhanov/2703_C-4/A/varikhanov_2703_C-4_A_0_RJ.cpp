#include <iostream>
#include<vector>

using namespace std;

int main()
{
    int m,n;
    cin >> n >> m;
    int mas[n];
    for(int i = 0; i < n; i++)
    {
        mas[i] = 0;
    }
    int u,v;
    for(int i = 0; i < m; i++)
    {
        cin >> u >> v;
        u--;
        v--;
        mas[u]++;
        mas[v]++;
    }
    for(int i = 0; i < n; i++)
    {
        cout << mas[i] << " ";
    }
    return 0;
}
