#include <iostream>

using namespace std;

int main()
{
    unsigned long int a,b,c,d;;
    cin>>a>>b;
    c=a;
    d=b;
    while(a!=0)
    {
        b=b%a;
        swap(a,b);
    }
    unsigned long int nok=(c*d)/b;
    cout<<nok;
    return 0;
}
