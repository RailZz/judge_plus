#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int mas[n];
    int a,b,c;
    for(int i=0;i<n;i++)
    {
        cin>>mas[i];
    }
    for(int i=0;i<n-1;i++)
    {
         while(mas[i]!=0)
          {
           mas[i+1]=mas[i+1]%mas[i];
           swap(mas[i],mas[i+1]);
          }

    }
        cout<<mas[n-1];


    return 0;
}
