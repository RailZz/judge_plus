#include <iostream>

using namespace std;
unsigned long long int nok(int a,int b)
{
    int c=a;
    int d=b;
    while(a!=0)
    {
        b=b%a;
        swap(a,b);
    }
    unsigned long long int nok=(c*d)/b;
    return(nok);
}
int main()
{
    unsigned long long int nk;
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    nk=nok(b,d);
    a=nk/b;
    c=nk/d;
    a=a+c;
    cout<<a<<" "<<nk;
    return 0;
}
