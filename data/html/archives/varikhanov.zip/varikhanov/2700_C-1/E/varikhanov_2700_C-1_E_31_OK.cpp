#include <iostream>

using namespace std;
int nod(int a,int b)
{
    while (a!=0)
      {
        b=b%a;
        swap(a,b);
      }
        return(b);
}
int main()
{
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    int low1=b;
    a=a*d;
    b=b*d;
    c=c*low1;
    a=a+c;
    int nd=nod(a,b);
    a=a/nd;
    b=b/nd;
    //cout<<nod(a,b)<<endl;
    cout<<a<<" "<<b;
    return 0;
}
