#include <iostream>

using namespace std;
bool mas[100000];
int main()
{
    int n;
    cin>>n;


    for(int i=1;i<n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            if((j+1)%(i+1)==0)
            {
                mas[j]=true;
            }
        }
            if(mas[i]==false)
                cout<<i+1<<" ";
    }

    return 0;
}
