#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    bool mas[n];
    for(int i=0;i<n;i++)
    {
        mas[i]=true;
    }
    for(int i=1;i<n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            if((j+1)%(i+1)==0)
            {
                mas[j]=false;
            }
        }
    }
    for(int i=1;i<n;i++)
    {
        if(mas[i]==true)
        {
            cout<<i+1<<" ";
        }

    }
    return 0;
}
