#include <iostream>

using namespace std;
bool prime(int a)
{
    bool prime=true;
    for(int i=2;i*i<a;i++)
    {
        if(a%i==0)
        {
            prime=false;
        }
    }
    return(prime);
}
int main()
{
    int n;
    cin>>n;
    int a,b;
    for(int i=2;i<n;i++)
    {
        if(prime(i)==true)
        {
            b=n-i;
            if(prime(b)==true)
             {
                a=i;
                i=n;
             }
        }
    }
    cout<<a<<" "<<b;
    return 0;
}
