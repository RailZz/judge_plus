#include <iostream>

using namespace std;

int main()
{
    int w, h, n;
    cin >> w >> h >> n;
    int r = max(w, h) * max(w, h);
    int l = 1;
    int m;
    while (r - l > 1)
    {
        m = (r + l) / 2;
        if (m * m >= w * h * n)
        {
            r = m;
        }
        else
        {
            l = m;
        }
    }
    if (r % max(w, h) == 0)
    {
       cout << r;
    }
    else
        cout << r + 1;
    return 0;
}
