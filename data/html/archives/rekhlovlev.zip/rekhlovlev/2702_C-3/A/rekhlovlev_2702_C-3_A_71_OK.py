def f(t):
    global x
    global y
    global N
    n = 0
    if t >= min(x, y):
        n += 1
        t -= min(x, y)
        n += t // x + t // y
    return n >= N

N, x, y = map(int, input().split())
l = 0
r = (x + y) * N
while r - l > 1:
    m = (r + l) // 2
    if f(m) :
        r = m
    else:
        l = m
print(r)
        