
def f(D):
    k = 0
    for i in range(1, D + 1):
        if i % K != 0:
            k += A
        if i % M != 0:
            k += B
    return k >= X
A, K, B, M, X = map(int, input().split())
l = 0
r = (A + B) * X
while r - l > 1:
    m = (r + l) // 2
    if f(m):
        r = m
    else:
        l = m
print(r)