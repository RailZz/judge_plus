
def f(x):
    global Places
    global K    
    cow = 0
    Busy = [0] * (N + 1)
    for i in range(N):
        if i != N and Busy[i] != 1:
            for k in range(i, N):
                if Places[k] == Places[i] + x:
                    cow += 1
    return cow >= K
N, K = map(int, input().split())
Places = list(map(int, input().split()))
l = 0
r = Places[-1] - Places[0]
while r - l > 1:
    m = (r + l) // 2
    if f(m):
        r = m
    else:
        l = m
print(r // 2)
    