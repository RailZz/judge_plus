def f(x):
    global Places
    global K
    Busy = [0] * (N + 1)
    for i in range(N):
        if Busy[i] != 1:
            k = 0
            while k < Places[-1] // x:
                if Places[i] == Places[i] + (k * x):
                    Busy[i] = 1
                    r = 0
                    while r < N:
                        if Places[r] == Places[i] + (k * x):
                            Busy[r] = 1
                        r += 1
                k += 1
    return sum(Busy) >= K


N, K = map(int, input().split())
Places = list(map(int, input().split()))
l = 0
r = Places[-1] - Places[0]
while r - l > 1:
    m = (r + l) // 2
    if f(m):
        l = m
    else:
        r = m
print(r // 2)
