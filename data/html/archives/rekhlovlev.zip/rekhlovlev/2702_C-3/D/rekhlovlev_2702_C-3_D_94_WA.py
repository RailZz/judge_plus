def f(x):
    k = 0
    global S
    global K
    for i in range(S[0], S[-1]):
        if (i + x) in S:
            k += 1
    return k >= K
N, K = map(int, input().split())
S = list(map(int, input().split()))
l = 0
r = S[-1] - S[0]
while r - l > 1:
    m = (r + l) // 2
    if f(m):
        l = m
    else:
        r = m
print(l)