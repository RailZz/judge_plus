def f(x):
    global Places
    global K
    Busy = [0] * Places[-1]
    Busy[Places[0]] = 1
    for i in range(Places[0] + x, Places[-1]):
        if i in Places:
            if Busy[i] != 1:
                Busy[i] = 1
    return sum(Busy) >= K


N, K = map(int, input().split())
Places = list(map(int, input().split()))
l = 0
r = Places[-1] - Places[0]
while r - l > 1:
    m = (r + l) // 2
    if f(m):
        l = m
    else:
        r = m
print(l)
