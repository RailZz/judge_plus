def f(m):
    s = 0
    global K
    global lens
    for i in range(N):
        s += lens[i] // m
    return s >= K
N, K = map(int, input().split())
lens = []
for i in range(N):
    lens.append(int(input()))
l = 0
r = 10 ** 9
while r - l > 1:
    m = (r + l) // 2
    if f(m):
        l = m
    else:
        r = m
print(l)