N = int(input())
G = [[int(i) for i in input().split()] for j in range(N)]
S, F = map(int, input().split())
S -= 1
F -= 1
points = 0
used = [0] * N
p = [1] * N
q = []
q.append(S)
way = []
d = [101] * N
while len(q) > 0:
    c = q.pop(0)
    for i in range(N):
        if used[i] == 0 and G[c][i] == 1:
            p[i] = c
            used[i] = 1
            d[i] = d[c] + 1
            q.append(i)
        else:
            print(-1)
            break


if S == F:
    print(0)
else:
    while F != S:
        way.append(F + 1)
        F = p[F]
    way.append(S + 1)
    k = len(way)
    if k - 1 == 0:
        print(-1)
    else:
        print(k - 1)
        for i in range(k - 1, -1, -1):
            print(way[i], end = ' ')
