N, M = map(int, input().split())
Svetofor = [0] * (N + 1)
for i in range(M):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    Svetofor[a] += 1
    Svetofor[b] += 1
for i in range(N):
    print(Svetofor[i], end = ' ')
