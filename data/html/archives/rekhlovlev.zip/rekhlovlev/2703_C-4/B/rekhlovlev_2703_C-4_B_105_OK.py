def dfs(v, used):
    global N
    global G
    used[v] = 1
    for i in range(N):
        if G[v][i] == 1 and used[i] == 0:
            dfs(i, used)


N, S = map(int, input().split())
G = [[int(i) for i in input().split()] for j in range(N)]
used = [0] * N
dfs(S - 1, used)
print(sum(used))