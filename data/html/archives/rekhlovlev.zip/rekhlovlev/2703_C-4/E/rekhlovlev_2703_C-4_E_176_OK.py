def dfs(v, used, p):
    used[v] = 1
    global cycle
    for i in G[v]:
        if used[i] == 0:
            dfs(i, used, v)
        else:
            if used[i] == 1 and i != p:
                cycle = 1


N, M = map(int, input().split())
G = [[] for i in range(N)]
for i in range(M):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    G[a].append(b)
    G[b].append(a)
used = [0] * N
cycle = 0
dfs(0, used, -1)
if cycle == 0 and sum(used) == N:
    print('YES')
else:
    print('NO')
