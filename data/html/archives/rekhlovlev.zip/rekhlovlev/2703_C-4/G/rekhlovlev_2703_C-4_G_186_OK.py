def dfs(v, used):
    used[v] = 1
    global cycle
    for i in range(N):
        if used[i] == 0 and G[v][i] == 1:
            dfs(i, used)
        elif used[i] == 1 and G[v][i] == 1:
            cycle = 1
    used[v] = 2


N = int(input())
G = [[int(i) for i in input().split()] for j in range(N)]
used = [0] * N
cycle = 0
for i in range(N):
    if used[i] == 0:
        dfs(i, used)
print(cycle)