def dfs(v, used, p):
    used[v] = 1
    global cycle
    for i in range(N):
        if used[i] == 0 and G[v][i] == 1:
            dfs(i, used, v)
        else:
            if used[i] == 1 and i != p and G[v][i] == 1:
                cycle = 1


N = int(input())
G = [[int(i) for i in input().split()] for j in range(N)]
used = [0] * N
cycle = 0
for i in range(N):
    if used[i] == 0:
        dfs(i, used, -1)
print(cycle)
