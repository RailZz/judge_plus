def dfs(v, used, color):
    used[v] = color
    global errors
    for i in G[v]:
        if used[i] == 0:
            dfs(i, used, 3 - color)
        elif used[i] == color:
            errors = 1


N, M = map(int, input().split())
G = [[] for i in range(N)]
for i in range(M):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    G[a].append(b)
    G[b].append(a)
used = [0] * N
errors = 0
color = 1
dfs(0, used, color)
if errors == 1:
    print('N0')
else:
    print('YES')
    for i in range(N):
        if used[i] == 1:
            print(i + 1, end = ' ')
