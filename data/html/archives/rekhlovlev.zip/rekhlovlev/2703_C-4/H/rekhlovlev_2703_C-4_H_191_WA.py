def dfs(x, y, used):
    global S
    used[x][y] = 1
    S += 1
    for d in range(4):
        nx = x + dx[d]
        ny = y + dy[d]
        if 0 < nx < N and 0 < ny < N:
            if used[nx][ny] == 0:
                dfs(nx, ny, used)


N = int(input())
field = [[i for i in input().split()] for j in range(N)]
i, j = map(int, input().split())
used = [[0] * N] * N
dx = [0, 1, 0, -1]
dy = [-1, 0, 1, 0]
S = 0
dfs(i, j, used)
print(S - 1)
