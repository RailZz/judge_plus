n = int(input())
G = [[int(i) for i in input().split()] for j in range(n)]
To = []
From = [1] + [0] * n
for i in range(n):
    if sum(G[i]) == 0:
        To.append(i + 1)
    for j in range(n):
        if G[i][j] == 1:
            From[j + 1] = 1
print(len(From) - sum(From))
for i in range(len(From)):
    if From[i] == 0:
        print(i)
print(len(To))
for j in To:
    print(j)
