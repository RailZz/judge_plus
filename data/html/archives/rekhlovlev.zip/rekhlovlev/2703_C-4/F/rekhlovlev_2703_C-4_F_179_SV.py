def dfs(v, used, cur_v):
    used[v] = 1
    cur_v.append(v)
    for i in G[v]:
        if used[i] == 0:
            dfs(i, used, cur_v)


N, M = map(int, input().split())
G = [[] for i in range(N)]
for i in range(M):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    G[a].append(b)
    G[b].append(a)
partition = []
used = [0] * N
components = 0
for i in range(N):
    if used[i] == 0:
        cur_v = []
        dfs(i, used, cur_v)
        components += 1
        partition.append(cur_v)
print(components)
for i in range(components):
    print(len(partition[i]))
    for  k in range(len(partition[i])):
        if k == len(partition[i]) - 1:
            print(partition[i][k] + 1)
        else:
            print(partition[i][k] + 1, end = ' ')
