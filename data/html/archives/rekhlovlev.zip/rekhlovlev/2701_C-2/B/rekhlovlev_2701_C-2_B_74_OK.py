from math import sin, pi
a = float(input())
l = - pi / 2
r = pi / 2
for i in range(100):
    m = (r + l) / 2
    if sin(m) > a:
        r = m
    else:
        l = m
print(l)
    