N, K = map(int, input().split())
F = list(map(int, input().split()))
S = list(map(int, input().split()))
def binsearch(F,x):
    l = 0
    r = len(F)
    while r - l > 1:
        m = (r + l) // 2
        if F[m] > x:
            r = m
        else:
            l = m
    if F[l] == x:
        return 'YES'
    else:
        return 'NO'
for i in S:
    print(binsearch(F, i))