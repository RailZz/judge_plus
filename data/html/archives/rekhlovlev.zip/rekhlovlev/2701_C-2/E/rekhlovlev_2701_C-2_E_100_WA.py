N = int(input())
F = sorted(list(map(int, input().split())))
M = int(input())
S = list(map(int, input().split()))
def binsearchleft(F,x):
    l = 0
    r = len(F)
    while r - l > 1:
        m = (r + l) // 2
        if F[m] > x:
            r = m
        else:
            l = m
    if F[l] == x:
        if l == 0:
            return -2
        else:
            return l
    else:
        return 0
def binsearchright(F,x):
    l = -1
    r = len(F) - 1
    while r - l > 1:
        m = (r + l) // 2
        if F[m] >= x:
            r = m
        else:
            l = m
    return r
for i in S:
    l = binsearchleft(F, i)
    if l == 0:
        print(0, end = ' ')
    if l == -2:
        print(1, end = ' ')
    else:
        print(l - binsearchright(F, i) + 1, end = ' ')