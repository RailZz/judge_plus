from math import sqrt
a = float(input())
l = 1
r = 10 ** 10
for i in range(100):
    m = (r + l) / 2
    if m ** 2 + sqrt(m) > a:
        r = m
    else:
        l = m
print(l)