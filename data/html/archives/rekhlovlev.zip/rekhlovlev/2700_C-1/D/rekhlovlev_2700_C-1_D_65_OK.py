def gcd(a,b):
    while b != 0:
        a, b = b, a % b
    return a 
N, K = map(int, input().split())
prod = N * K
print(prod // gcd(N,K))