n = int(input())
SV = [0] * (n + 4)
for i in range(2, n + 1):
    if SV[i] == 0:
        for j in range(i * 2, n + 1, i):
            SV[j] = 1
for i in range(2, n + 1):
    if SV[i] == 0:
        print(i, end = ' ')