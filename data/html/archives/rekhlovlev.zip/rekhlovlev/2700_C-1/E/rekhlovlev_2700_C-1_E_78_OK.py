def gcd(a,b):
    while b != 0:
        a, b = b, a % b
    return a 
a, b, c, d = map(int, input().split())

prod = b * d
lcd = prod // gcd(b,d)
minim = gcd(a * (lcd // b) + c * (lcd // d), lcd)
print((a * (lcd // b) + c * (lcd // d))//minim, lcd//minim)