def dels(x):
    ans = 1
    i = 2 
    while i * i < x:
        if x % i == 0:
            ans += i
            ans += x // i
        i += 1
    return ans
    
n = int(input())
i = 220
while i < n:
    m = dels(i)
    k = dels(m)
    save = max(i, m)
    if k == i and i != save:
        print(min(i, m), max(i, m))
    i += 1