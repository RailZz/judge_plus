n = int(input())
SV = [0] * (n + 4)
for i in range(2, n + 1):
    if SV[i] == 0:
        for j in range(i * 2, n + 1, i):
            SV[j] = 1
for i in range(2, n + 1):
    for j in range(i, n + 1):
        if SV[i] == 0 and SV[j] == 0:
            if i + j == n:
                print(i, j)
                quit()