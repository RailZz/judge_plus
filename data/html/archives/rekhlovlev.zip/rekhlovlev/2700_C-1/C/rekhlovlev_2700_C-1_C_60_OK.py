def gcd(a,b):
    while b != 0:
        a, b = b, a % b
    return a    
n = int(input())
a = list(map(int, input().split()))
S = a[0]
for i in a:
    S = gcd(S, i)
print(S)