N = int(input())
K = int(input())
exits = [int(i) - 1 for i in input().split()]
M = int(input())
G = [[] for i in range(N)]
for i in range(M):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    G[a].append(b)
    G[b].append(a)
q = []
time = [0 for i in range(N)]
ans = []
used = [0] * N
p = [0] * N
for i in exits:
    q.append(i)
    time[i] = 0
    used[i] = 1
    while len(q) > 0:
        c = q.pop()
        for u in G[c]:
            if used[u] == 0:
                used[u] = 1
                p[u] = c
                time[u] = time[c] + 1
                q.append(u)
            elif used[u] == 1 and time[c] + 1 < time[u]:
                time[u] = time[c] + 1
                q.append(u)
print(*time)
