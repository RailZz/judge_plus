def f(x):
    if (x // h) * (x // w) >= n:
        return True
    else:
        return False


w, h, n = map(int, input().split())
l = -1
r = (w + h) * n
while r - l > 1:
    m = (r + l) // 2
    if f(m):
        r = m
    else:
        l = m
print(r)
