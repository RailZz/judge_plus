N = int(input())
A, B, C = map(int, input().split())
d = [0] * (N + 1)
d[1] = 1
for i in range(1, N + 1):
    if i + A < N + 1 and d[i + A] == 0 and d[i] == 1:
        d[i + A] = 1
    if i + B < N + 1 and d[i + B] == 0 and d[i] == 1:
        d[i + B] = 1
    if i + C < N + 1 and d[i + C] == 0 and d[i] == 1:
        d[i + C] = 1
if A == 1 or B == 1 or C == 1:
    print(sum(d) - 1)
elif A >= N or B >= N or C >= N:
    print(0)
else:
    print(sum(d))
