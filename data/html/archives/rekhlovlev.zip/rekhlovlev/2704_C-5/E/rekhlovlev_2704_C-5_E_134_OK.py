N, M = map(int, input().split())
Pay = [[int(i) for i in input().split()] for j in range(N)]
d = [[0 for i in range(M)] for j in range(N)]
d[0][0] = Pay[0][0]
ans = []
p = [[[] for i in range(M)] for j in range(N)]
for i in range(0, N):
    for j in range(0, M):
        if i > 0 and j > 0:
            d[i][j] = min(d[i][j - 1], d[i - 1][j]) + Pay[i][j]
        elif i == 0 and j == 0:
            d[i][j] = Pay[i][j]
        elif i == 0:
            d[i][j] = d[i][j - 1] + Pay[i][j]
        elif j == 0:
            d[i][j] = d[i - 1][j] + Pay[i][j]
print(d[N - 1][M - 1])
