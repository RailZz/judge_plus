N = int(input())
pay = list(map(int,input().split()))
d = [0] * (N + 1)
d[1] = pay[0]
d[2] = pay[1]
for i in range(3, N + 1):
    d[i] = pay[i - 1] + min(d[i - 1], d[i -2])
print(min(d[N], d[N - 1]))
