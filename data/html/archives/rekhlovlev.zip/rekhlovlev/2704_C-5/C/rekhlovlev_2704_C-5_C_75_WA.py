N = int(input())
pay = list(map(int, input().split()))
d = [0] * (N + 1)
if len(pay) == 1:
    print(pay[0])
elif len(pay) == 2:
    print(min(pay[0], pay[1]))
else:
    d[1] = pay[0]
    d[2] = pay[1]
    for i in range(3, N + 1):
        d[i] = pay[i - 1] + min(d[i - 1], d[i - 2])
    print(d[N])
