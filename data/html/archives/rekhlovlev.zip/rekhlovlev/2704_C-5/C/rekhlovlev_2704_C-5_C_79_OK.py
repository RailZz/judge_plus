N = int(input())
pay = list(map(int, input().split()))
d = [0] * (N + 1)
if len(pay) == 1:
    print(pay[0])
elif len(pay) == 2:
    print(pay[1])
else:
    d[0] = pay[0]
    d[1] = pay[1]
    for i in range(2, N):
        d[i] = pay[i] + min(d[i - 1], d[i - 2])
    print(d[N - 1])
