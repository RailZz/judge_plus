N, M = map(int, input().split())
dy = [-2, -1, 1, 2, 2, 1, -1, -2]
dx = [1, 2, 2, 1, -1, -2, -2, -1]
used = [[0 for i in range(N)] for j in range(M)]
din = [[0 for i in range(N)] for j in range(M)]
for x in range(N):
    for y in range(M):
        for d in range(8):
            nx = x + dx[d]
            ny = y + dy[d]
            if 0 <= nx < N and 0 <= ny < M and used[nx][ny] == 0:
                din[nx][ny] += din[x][y] + 1
                used[nx][ny] = 1
print(din[N - 1][M - 1])
