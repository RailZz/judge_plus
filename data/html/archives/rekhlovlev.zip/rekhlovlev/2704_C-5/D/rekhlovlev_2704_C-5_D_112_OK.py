N = int(input())
d = [10 ** 8] * (N + 1)
d[1] = 1
p = [1] * (N + 1)
for i in range(1, N + 1):
    if i + 1 < N + 1 and d[i + 1] > d[i] + 1:
        d[i + 1] = d[i] + 1
        p[i + 1] = i
    if i * 2 < N + 1 and d[i * 2] > d[i] + 1:
        d[i * 2] = d[i] + 1
        p[i * 2] = i
    if i * 3 < N + 1 and d[i * 3] > d[i] + 1:
        d[i * 3] = d[i] + 1
        p[i * 3] = i
ans = ''
if N > 1:
    x = N
    while x != 1:
        if x - 1 == p[x]:
            ans += '1'
        elif x % 2 == 0 and x // 2 == p[x]:
            ans += '2'
        elif x % 3 == 0 and x // 3 == p[x]:
            ans += '3'
        x = p[x]
print(ans[::-1])
