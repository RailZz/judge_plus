N = input()
if N[::-1] == N:
    print('yes')
else:
    print('no')