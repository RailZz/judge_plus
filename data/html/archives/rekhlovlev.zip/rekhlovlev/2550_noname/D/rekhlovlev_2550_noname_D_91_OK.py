F = list(map(int, input().split()))
x = 0
for i in range(1, len(F) - 1):
    if F[i] > F[i - 1] and F[i] > F[i + 1]:
        x += 1
print(x)

