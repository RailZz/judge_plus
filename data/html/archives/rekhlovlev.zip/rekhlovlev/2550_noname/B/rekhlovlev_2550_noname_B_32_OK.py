x = int(input())
sign = 0
if x > 0:
    sign = 1
if x < 0:
    sign = -1
if x == 0:
    sign = 0
print(sign)