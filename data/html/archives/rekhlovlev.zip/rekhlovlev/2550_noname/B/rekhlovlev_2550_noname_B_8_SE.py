x = int(input())
print(sign(x))