n = int(input())
limit = n // 2
i = 2
while i <= limit : 
    if n % i == 0:
        print('composite')
    i += 1
print('prime')