from math import sin
from math import pi
a = float(input())
l = -pi/2
r = pi/2
for i in range(100):
    m = (r + l) / 2
    my = sin(m)
    if my > a:
        r = m
    else:
        l = m
print(l)