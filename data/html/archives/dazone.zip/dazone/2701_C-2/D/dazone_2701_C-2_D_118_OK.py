from math import sin
from math import sqrt
a = float(input())
l = 1
r = 10 ** 20
for i in range(100):
    m = (r + l) / 2
    my = m * m + sqrt(m)
    if my > a:
        r = m
    else:
        l = m
print(l)