n, k = [int(i) for i in input().split()]
c = [int(i) for i in input().split()]
d = [int(i) for i in input().split()]
for i in range(k):
    l = 0
    r = n
    while r-l > 1:
        m = (l+r)//2
        if c[m] <= d[i]:
            l=m
        else:
            r=m
    if c[l] == d[i]:
        print('YES')
    else:
        print('NO')    