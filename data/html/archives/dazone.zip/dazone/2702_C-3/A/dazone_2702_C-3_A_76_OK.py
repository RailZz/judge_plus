def min(a,b):
    if a > b:
        return b
    else:
        return a
    
def f(t):
    n=0
    if t >= min(x,y):
        n+=1
        t-=min(x,y)
        n+=(t//x)+(t//y)
    return n >= N

N, x, y = [int(i) for i in input().split()]
l=0
r=(x+y)*N
m=0
while r-l > 1:
    m=(l+r)//2
    if f(m):
        r=m
    else:
        l=m
print(r)