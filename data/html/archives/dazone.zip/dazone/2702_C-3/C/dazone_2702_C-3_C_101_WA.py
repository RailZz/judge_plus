A, K, B, M, X = [int(i) for i in input().split()]
d=0
while X >= 0:
    d+=1
    if d % K != 0:
        X-=A
    if d % M != 0:
        X-=B
print(d)