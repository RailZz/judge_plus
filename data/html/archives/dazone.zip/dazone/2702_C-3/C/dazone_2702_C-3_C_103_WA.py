def f(x):
    X=Y
    d=X//((A*((K-1)/K))+(B*((M-1)/M)))     
    return d >= x

A, K, B, M, X = [int(i) for i in input().split()]
Y=X
l=0
r=10**20
m=0
while r-l > 1:
    m=(l+r)//2
    if f(m):
        l=m
    else:
        r=m
print(l)
    