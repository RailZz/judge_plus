def f(x):
    X=Y
    d=0
    while X > 0:
        d+=1
        if d % K != 0:
            X-=A
        if d % M != 0:
            X-=B        
    return d >= x

A, K, B, M, X = [int(i) for i in input().split()]
Y=X
l=0
r=10**20
m=0
while r-l > 1:
    m=(l+r)//2
    if f(m):
        l=m
    else:
        r=m
print(l)