A, K, B, M, X = [int(i) for i in input().split()]
print(int(X//((A*((K-1)/K))+(B*((M-1)/M)))))