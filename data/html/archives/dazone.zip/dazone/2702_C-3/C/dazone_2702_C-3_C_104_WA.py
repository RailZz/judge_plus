def f(x):
    d=(X//(A+B))
    d+=d//K+d//M
    return d >= x

A, K, B, M, X = [int(i) for i in input().split()]
l=0
r=10**20
m=0
while r-l > 1:
    m=(l+r)//2
    if f(m):
        l=m
    else:
        r=m
print(l)