def f(x):
    s=0
    for i in range(N):
        s += L[i]//x
    return s >= K

N, K = [int(i) for i in input().split()]
L = []
for i in range(N):
    L.append(int(input()))
l=0
r=10**20
m=0
while r-l > 1:
    m=(l+r)//2
    if f(m):
        l=m
    else:
        r=m
print(l)