sum = 0
N = int(input())
for i in range(N):
    a = int(input())
    sum += a
print(sum)