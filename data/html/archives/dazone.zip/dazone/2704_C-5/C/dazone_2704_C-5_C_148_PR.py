n = int(input())
a = [int(i) for i in input().split()]
if len(a) == 1:
    print(a[0])
elif len(a) == 2:
    print(a[1])
else:
    d = [0] * (n + 1)
    d[0] = a[0]
    d[1] = a[1]
    for i in range(2, n):
        d[i] = min(d[i - 1], d[i - 2]) + a[i]
    print(d[n - 1])