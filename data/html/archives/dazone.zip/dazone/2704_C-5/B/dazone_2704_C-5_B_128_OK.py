n = int(input())
d = [0] * (n + 1)
d[0] = 1
for i in range(0, n):
    d[i + 1] += d[i]
    if i + 2 <= n:
        d[i + 2] += d[i]
    if i + 3 <= n:
        d[i + 3] += d[i]
print(d[n])