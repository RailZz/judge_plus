a, b, c, d = [int(i) for i in input().split()]
if b == d:
    print(a+c, b)
else:
    e = b
    f = d
    while b != 0 and d != 0:
        b, d = d, b % d
    lcm = e*f//(b+d)
    print(a*lcm//e+c*lcm//f, lcm)