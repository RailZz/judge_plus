N, K = [int(i) for i in input().split()]
a = N
b = K
while a != 0 and b != 0:
    a, b = b, a % b
lcm = N * K // (a + b)
print(lcm)