a, b, c, d = [int(i) for i in input().split()]
if b == d:
    h = a+c
    while h != 0 and b != 0:
        h, b = b, h % b    
    print(a+c//(h+b), d//(h+b))
else:
    e = b
    f = d
    while b != 0 and d != 0:
        b, d = d, b % d
    lcm = e*f//(b+d)
    sum = a*lcm//e+c*lcm//f
    l = lcm
    s = sum
    while s != 0 and l != 0:
        s, l = l, s % l
    print(sum//(s+l), lcm//(s+l))