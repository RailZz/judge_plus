K = int(input())
a = K
for i in range(1000):
    if (K // 100 == K % 100 // 10 == K % 10) or (K // 10 == K % 10) or (K<10):
        if K // 100 != 0:
            digits = 3
        elif K // 10 != 0:
            digits = 2
        else:
            digits = 1
        print(K % 10, digits)
        break
    K += a
else:
    print('Impossible')