N = int(input())
n = 1
k = 1
for i in range(2, N+1):
    n *= i
dividers = [1]
i = 2
while i*i <= n:
    while n % i == 0:
        dividers.append(i)
        i += 1
        k += 1
if dividers[len(dividers)-1] != n//2:
    dividers.append(n//2)
    k += 1
k += 1
print(k)