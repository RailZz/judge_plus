N = int(input())
num = list(range(2, N))
len = num[len(num) - 1]
for b in num:
    if b * b <= len:
        for i in range(len+1 // b * b):
            if b * b + i * b in num:
                num.remove(b * b + i * b)
for i in num:
    print(i, end = ' ')