N = int(input())
num = list(range(2, N))
len = num[len(num) - 1]
for b in num:
    if b * b <= len:
        for i in range(b, len+1 // b * b):
            if b * i in num:
                num.remove(b * i)
for i in num:
    print(i, end = ' ')
