N = int(input())
num = list(range(2, N))
len = num[len(num) - 1]
i = 2
while i * i <= len:
    for j in range(len // i * i):
        dig = i * i + j * i
        if dig in num:
            num.remove(dig)
    i += 1
for i in num:
    print(i, end = ' ')