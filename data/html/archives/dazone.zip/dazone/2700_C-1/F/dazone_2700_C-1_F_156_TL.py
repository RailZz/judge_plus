N = int(input())
num = list(range(2, N))
len = num[len(num) - 1]
for b in num:
    for i in range(2, len+1 // b):
        if b * i in num:
            num.remove(b * i)
    b += 1
for i in num:
    print(i, end = ' ')