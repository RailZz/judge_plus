N = int(input())
list = [int(i) for i in input().split()]
for i in range(N-1):
    a = list[i]
    b = list[i+1]
    while (a != 0) and (b != 0):
        a, b = b, a % b
    list[i+1] = (a+b)
print(list[N-1])
