def solve (n):
  i=2
  for i in range (i, n-1):
    if n % i == 0:
      print('composite')
      break
  else: print('prime')
solve(int(input()))