def solve (n):
  i=2
  while i*i<=n:
    if n % i == 0:
      print('composite')
      break
  else: print('prime')
solve(int(input()))