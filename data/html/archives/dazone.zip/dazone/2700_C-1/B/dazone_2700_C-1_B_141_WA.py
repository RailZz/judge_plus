def solve(n):
    primes = []
    i=2
    while i*i <= n:
        while n % i == 0:
            primes.append(i)
            n = n//i
        i += 1
        if n != 1:
            primes.append(n)
            for i in primes:
                print(i, end = ' ')
            
solve(int(input()))