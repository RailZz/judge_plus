def dfs(v, color):
    global good
    used[v] = color
    for i in G[v]:
        if used[i] == 0:
            dfs(i, 3 - color)
        elif used[i] == color:
            good = 0
            break


N, M = [int(i) for i in input().split()]
G = [[] for i in range(N)]
for i in range(M):
    i, j = [int(i) for i in input().split()]
    i -= 1
    j -= 1
    G[i].append(j)
    G[j].append(i)
good = 1
used = [0] * N
dfs(0, 1)
if good != 0:
    first = []
    k = 1
    for i in used:
        if i == 1:
            first.append(k)
        k += 1
    first.sort()
    for i in first:
        print(i, end=' ')
    print()
    second = []
    k = 1
    for i in used:
        if i == 2:
            second.append(k)
        k += 1
    second.sort()
    for i in second:
        print(i, end=' ')
else:
    print(good)