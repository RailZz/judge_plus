def dfs(v, color):
    global good
    used[v] = color
    for i in G[v]:
        if used[i] == 0:
            dfs(i, 3 - color)
        elif used[i] == color:
            good = 0
            break


N, M = [int(i) for i in input().split()]
G = [[] for i in range(N)]
for i in range(M):
    i, j = [int(i) for i in input().split()]
    i -= 1
    j -= 1
    G[i].append(j)
    G[j].append(i)
good = 1
used = [0] * N
dfs(0, 1)
if good != 0:
    k = 1
    for i in used:
        if i == 1:
            print(k, end=' ')
        k += 1
    k = 1
    print()
    for i in used:
        if i == 2:
            print(k, end=' ')
        k += 1
else:
    print(good)