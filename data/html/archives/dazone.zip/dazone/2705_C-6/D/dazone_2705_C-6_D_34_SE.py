def solve():
    def dfs(v):
        used[v] = 1
        for i in buttons:
            if v + i <= N-1:
                if used[v + i] == 0:
                    dfs(v + i)


    N = int(input())
    buttons = [int(i) for i in input().split()]
    used = [0] * (N + 10)
    dfs(0)
    print(sum(used))


solve()