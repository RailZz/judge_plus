n = int(input())
k = 1
i = 2
while i * i < n:
    if n % i == 0:
        k += 1
    i += 1
i = 1
a = 0
while i * i <= n:
    a = i * i
    i += 2
if n == 1:
    print(1)
elif n == a:
    print(k * 2 + 1)
else:
    print(k * 2)