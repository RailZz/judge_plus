n = int(input())
k = 1
i = 2
while i * i < n:
    if n % i == 0:
        k += 1
    i += 1
if n % 2 == 0:
    print(k * 2)
else:
    print(k * 2 + 1)