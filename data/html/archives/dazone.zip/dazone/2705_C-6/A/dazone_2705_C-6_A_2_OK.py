def size(a):
    return (a // w) * (a // h) >= n


w, h, n = [int(i) for i in input().split()]
l = 0
r = 10**18
while r - l > 1:
    m = (r + l) // 2
    if size(m):
        r = m
    else:
        l = m
print(r)