N, M = [int(i) for i in input().split()]
G = [[] for i in range(N)]
for i in range(M):
    i, j = [int(i) for i in input().split()]
    G[j - 1].append(i)
    G[i - 1].append(j)
for i in G:
    print(len(i), end = ' ')