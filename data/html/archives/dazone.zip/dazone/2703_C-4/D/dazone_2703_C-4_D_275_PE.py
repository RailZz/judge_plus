def dfs(V, color):
    used[V] = color
    global ans
    for i in G[V]:
        if used[i] == 0:
            dfs(i, 3 - color)
        elif used[i] == color:
            ans = 'NO'
            break


N, M = [int(i) for i in input().split()]
used = [0] * N
ans = 'YES'
G = [[] for i in range(N)]
for i in range(M):
    i, j = [int(i) for i in input().split()]
    i -= 1
    j -= 1
    G[i].append(j)
    G[j].append(i)
for i in range(N):
    if used[i] == 0:
        dfs(i, 1)
bad = []
print(ans)
if ans == 'NO':
    print(ans)
else:
    for i in range(N):
        if used[i] == 1:
            bad.append(i + 1)
print(*bad)
