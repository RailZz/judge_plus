def solve():


    from sys import setrecursionlimit
    setrecursionlimit(10**9)
    def dfs(V, used, curv):
        used[V] = 1
        curv.append(V)
        for i in G[V]:
            if used[i] == 0:
                dfs(i, used, curv)
    
    
    N, M = [int(i) for i in input().split()]
    used = [0] * N
    G = [[] for i in range(N)]
    for i in range(M):
        i, j = [int(i) for i in input().split()]
        i -= 1
        j -= 1
        G[i].append(j)
        G[j].append(i)
    partition = []
    for i in range(N):
        if used[i] == 0:
            curv = []
            dfs(i, used, curv)
            partition.append(curv)
    print(len(partition))
    for i in range(len(partition)):
        print(len(partition[i]))
        for j in partition[i]:
            partition[i].sort()
            print(j + 1, end=' ')
        print('')


solve()