def dfs(V, G, used):
    used[V] = 1
    for i in G[V]:
        if used[i] == 0:
            dfs(i, G, used)


N, S = [int(i) for i in input().split()]
G = [[int(i) for i in input().split()] for j in range(N)]
used = [0] * N
S -= 1
for i in range(N):
    for j in range(N):
        if G[i][j] == 1:
            G[i].append(j)
dfs(S, G, used)
print(sum(used))
