def dfs(V, p):
    global cycle
    used[V] = 1
    for i in G[V]:
        if used[i] == 0:
            dfs(i, V)
        elif p != i:
            cycle = '1'
            break
            

N = int(input())
M = [[int(i) for i in input().split()] for j in range(N)]
used = [0] * N
cycle = '0'
G = [[] for i in range(N)]
for i in range(N):
    for j in range(N):
        if M[i][j] == 1:
            G[i].append(j)     
dfs(0, -1)
print(cycle)