def dfs(V, used, p):
    used[V] = 1
    global tree
    for i in G[V]:
        if used[i] == 0:
            dfs(i, used, V)
        elif i != p:
            tree = 'NO'
            break


N, M = [int(i) for i in input().split()]
tree = 'YES'
if M != 0 and N >= M:
    used = [0] * N
    G = [[] for i in range(N)]
    for i in range(M):
        i, j = [int(i) for i in input().split()]
        i -= 1
        j -= 1
        G[i].append(j)
        G[j].append(i)
    dfs(0, used, -1)
else:
    tree = 'NO'
if M != 0 and sum(used) != N:
    tree = 'NO'
print(tree)