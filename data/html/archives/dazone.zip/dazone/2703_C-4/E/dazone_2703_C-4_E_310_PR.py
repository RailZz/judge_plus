def dfs(V, used, p):
    used[V] = 1
    global tree
    for i in G[V]:
        if used[i] == 0:
            dfs(i, used, V)
        elif i != p:
            tree = 'NO'
            break


N, M = [int(i) for i in input().split()]
tree = 'YES'
used = [0] * N
G = [[] for i in range(N)]
for i in range(M):
    i, j = [int(i) for i in input().split()]
    if i != 0 and j != 0:
        i -= 1
        j -= 1
        G[i].append(j)
        G[j].append(i)
dfs(0, used, -1)
if not (sum(used) == N and tree == 'YES'):
    tree = 'NO'
if N == 1 and M != 0:
    tree = 'NO'
elif N == 2 and M > 1:
    tree = 'NO'
elif N == 2 and M == 1:
    tree = 'YES'
print(tree)