def dfs(V, used, p):
    used[V] = 1
    for i in G[V]:
        if used[i] == 0:
            dfs(i, used, V)
        elif i != p:
            return 'NO'
    else:
        return 'YES'


N, M = [int(i) for i in input().split()]
p = -1
used = [0] * N
G = [[] for i in range(N)]
for i in range(M):
    i, j = [int(i) for i in input().split()]
    i -= 1
    j -= 1
    G[i].append(j)
    G[j].append(i)
print(dfs(0, used, p))